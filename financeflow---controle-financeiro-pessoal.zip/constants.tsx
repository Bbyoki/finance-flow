import React from 'react';
import { 
  Utensils, 
  Car, 
  Home, 
  Gamepad2, 
  Heart, 
  ShoppingBag, 
  MoreHorizontal,
  Briefcase,
  Bitcoin,
  PieChart,
  Layers,
  Laptop,
  Target,
  PiggyBank,
  Plane,
  Sparkles,
  ShieldCheck,
  GraduationCap,
  TrendingUp
} from 'lucide-react';

export const CATEGORIES = [
  { id: 'Alimentação', icon: <Utensils size={18} /> },
  { id: 'Transporte', icon: <Car size={18} /> },
  { id: 'Moradia', icon: <Home size={18} /> },
  { id: 'Lazer', icon: <Gamepad2 size={18} /> },
  { id: 'Saúde', icon: <Heart size={18} /> },
  { id: 'Compras', icon: <ShoppingBag size={18} /> },
  { id: 'Investimentos', icon: <TrendingUp size={18} /> },
  { id: 'Metas / Objetivos', icon: <Target size={18} /> },
  { id: 'Trabalho / Salário', icon: <Briefcase size={18} /> },
  { id: 'Eletrônicos', icon: <Laptop size={18} /> },
  { id: 'Educação', icon: <GraduationCap size={18} /> },
  { id: 'Outros', icon: <MoreHorizontal size={18} /> },
];

export const GOAL_CATEGORIES = [
  { id: 'Eletrônicos & PC', icon: <Laptop size={18} /> },
  { id: 'Móveis & Casa', icon: <Home size={18} /> },
  { id: 'Reserva Financeira', icon: <PiggyBank size={18} /> },
  { id: 'Viagens & Férias', icon: <Plane size={18} /> },
  { id: 'Veículo & Transporte', icon: <Car size={18} /> },
  { id: 'Educação & Cursos', icon: <GraduationCap size={18} /> },
  { id: 'Outros Objetivos', icon: <Target size={18} /> }
];

export const INVESTMENT_TYPES = [
  { id: 'CRYPTOCURRENCY', label: 'Criptomoedas', icon: <Bitcoin className="text-amber-400" size={18} /> },
  { id: 'STOCKS', label: 'Ações / B3', icon: <Briefcase className="text-blue-400" size={18} /> },
  { id: 'FUNDS', label: 'Fundos Imobiliários / FIIs', icon: <PieChart className="text-purple-400" size={18} /> },
  { id: 'FIXED_INCOME', label: 'Renda Fixa / Tesouro / CDB', icon: <ShieldCheck className="text-emerald-400" size={18} /> },
  { id: 'OTHER', label: 'Outros Ativos', icon: <Layers className="text-slate-400" size={18} /> },
];

export const DEFAULT_INVESTMENT_FOLDERS = [
  'Cripto',
  'Ações',
  'Renda Fixa',
  'FIIs',
  'Reserva',
  'Geral'
];

export const MONTHS = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];
