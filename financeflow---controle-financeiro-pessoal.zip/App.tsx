import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Plus, 
  Wallet, 
  CreditCard as CardIcon, 
  TrendingUp, 
  LayoutDashboard, 
  Calendar,
  X,
  Download,
  Upload,
  Clock,
  Edit2,
  Trash2,
  AlertCircle,
  CheckCircle2,
  Target,
  Zap,
  ChevronRight,
  Bell,
  Repeat
} from 'lucide-react';
import { db } from './services/db';
import { 
  AppState, 
  View, 
  Transaction, 
  TransactionType, 
  MonthlyBill, 
  Investment, 
  InvestmentType, 
  CreditCard,
  Goal,
  RetentionSettings
} from './types';
import { CATEGORIES, INVESTMENT_TYPES, GOAL_CATEGORIES, DEFAULT_INVESTMENT_FOLDERS } from './constants';
import { MobileDateTimeInput } from './components/MobileDateTimeInput';
import { BillsView } from './components/BillsView';
import { CardsView } from './components/CardsView';
import { GoalsView } from './components/GoalsView';
import { InvestmentsView } from './components/InvestmentsView';
import { TransactionsView } from './components/TransactionsView';
import { NotificationsModal } from './components/NotificationsModal';
import { AutoIncomeModal } from './components/AutoIncomeModal';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<View>('DASHBOARD');
  const [state, setState] = useState<AppState>(() => {
    const { state } = db.load();
    return state;
  });

  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [modalType, setModalType] = useState<'TRANSACTION' | 'BILL' | 'INVESTMENT' | 'CARD' | 'GOAL'>('TRANSACTION');
  const [editingItem, setEditingItem] = useState<any>(null);
  const [deletingItem, setDeletingItem] = useState<any>(null);

  // Auto income modal
  const [showAutoIncomeModal, setShowAutoIncomeModal] = useState<boolean>(false);

  // Notifications modal
  const [showNotificationsModal, setShowNotificationsModal] = useState<boolean>(false);

  // Form states for Transaction modal
  const [transactionDate, setTransactionDate] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<string>('');
  const [selectedCardId, setSelectedCardId] = useState<string>('');
  const [transactionType, setTransactionType] = useState<TransactionType>('EXPENSE');

  // Form states for Bill modal (Multi-due dates and Subscriptions)
  const [billDueDates, setBillDueDates] = useState<string[]>([new Date().toISOString().slice(0, 10)]);
  const [billIsSubscription, setBillIsSubscription] = useState<boolean>(false);
  const [billSubscriptionDay, setBillSubscriptionDay] = useState<number>(10);

  // Form state for Investment folder and existing asset
  const [investmentFolder, setInvestmentFolder] = useState<string>('Geral');
  const [investmentMode, setInvestmentMode] = useState<'NEW' | 'EXISTING'>('NEW');
  const [selectedExistingInvId, setSelectedExistingInvId] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  // Check for auto-income credits on mount
  useEffect(() => {
    const { autoIncomesAdded } = db.load();
    if (autoIncomesAdded && autoIncomesAdded.length > 0) {
      const totalCredited = autoIncomesAdded.reduce((acc, i) => acc + i.amount, 0);
      showToast(`💰 Saldo automático creditado: R$ ${totalCredited.toFixed(2)} (Dia ${autoIncomesAdded[0].day})`, 'success');
    }
  }, []);

  // Stats Calculations
  const stats = useMemo(() => {
    const income = state.transactions
      .filter(t => t.type === 'INCOME')
      .reduce((a, b) => a + b.amount, 0);

    const expenses = state.transactions
      .filter(t => t.type === 'EXPENSE')
      .reduce((a, b) => a + b.amount, 0);

    // Immediate expenses are cash, pix, debit, boleto (not charged on credit card)
    const immediateExpenses = state.transactions
      .filter(t => t.type === 'EXPENSE' && t.paymentMethod !== 'Crédito' && !t.cardId)
      .reduce((a, b) => a + b.amount, 0);

    // Invoices paid towards credit cards also deduct cash
    const invoicesPaidTotal = state.paidCardInvoices.reduce((a, b) => a + b.amountPaid, 0);

    // Paid bills
    const billsPaid = state.paidBillsHistory.reduce((a, b) => a + b.amount, 0);
    const billsPending = state.bills.reduce((a, b) => a + b.amount, 0);

    // Calculate cards debt
    const cardExpenses = state.transactions
      .filter(t => t.type === 'EXPENSE' && !!t.cardId)
      .reduce((a, b) => a + b.amount, 0);
    const cardRefunds = state.transactions
      .filter(t => t.type === 'INCOME' && !!t.cardId)
      .reduce((a, b) => a + b.amount, 0);
    const totalCardsDebt = Math.max(0, cardExpenses - cardRefunds - invoicesPaidTotal);

    // Investments total
    const investmentsTotal = state.investments.reduce((a, b) => a + b.amount, 0);

    // Goals total
    const goalsTotal = state.goals.reduce((a, b) => a + b.currentAmount, 0);

    // True Cash Balance (income minus cash expenses and paid bills)
    const balance = income - immediateExpenses - billsPaid;

    return { 
      income, 
      expenses, 
      billsPending, 
      billsPaid, 
      investmentsTotal, 
      goalsTotal, 
      totalCardsDebt, 
      balance 
    };
  }, [state]);

  // Notifications count for header bell badge (ignoring dismissed alerts)
  const notificationCount = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dismissed = state.dismissedNotificationIds || [];
    let count = 0;

    state.bills.forEach(bill => {
      bill.dueDates.forEach(dStr => {
        if (bill.paidDueDates.includes(dStr)) return;
        const notifId = `bill_${bill.id}_${dStr}`;
        if (dismissed.includes(notifId)) return;

        const parts = dStr.split('-');
        if (parts.length === 3) {
          const d = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
          d.setHours(0, 0, 0, 0);
          const diffDays = Math.ceil((d.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
          if (diffDays <= 5) count++;
        }
      });
    });

    const currentDay = today.getDate();
    const cardMonthKey = `${today.getFullYear()}-${today.getMonth() + 1}`;
    state.cards.forEach(card => {
      const cardNotifId = `card_${card.id}_${cardMonthKey}`;
      if (dismissed.includes(cardNotifId)) return;

      let diff = card.dueDay - currentDay;
      if (diff < 0) diff += 30;
      if (diff <= 3) count++;
    });

    return count;
  }, [state.bills, state.cards, state.dismissedNotificationIds]);

  // Setup modals on open
  useEffect(() => {
    if (showAddModal) {
      if (editingItem) {
        setTransactionDate(editingItem.date || '');
        setPaymentMethod(editingItem.paymentMethod || '');
        setSelectedCardId(editingItem.cardId || '');
        setTransactionType(editingItem.type || 'EXPENSE');
        if (editingItem.dueDates && editingItem.dueDates.length > 0) {
          setBillDueDates(editingItem.dueDates);
        } else if (editingItem.dueDate) {
          setBillDueDates([editingItem.dueDate]);
        }
        setBillIsSubscription(!!editingItem.isSubscription);
        setBillSubscriptionDay(editingItem.subscriptionDay || (editingItem.dueDates?.[0] ? parseInt(editingItem.dueDates[0].split('-')[2]) : 10));
        if (editingItem.folder) {
          setInvestmentFolder(editingItem.folder);
        }
      } else {
        const now = new Date();
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        setTransactionDate(now.toISOString().slice(0, 16));
        setPaymentMethod('');
        setSelectedCardId(state.cards.length > 0 ? state.cards[0].id : '');
        setTransactionType('EXPENSE');
        setBillDueDates([new Date().toISOString().slice(0, 10)]);
        setBillIsSubscription(false);
        setBillSubscriptionDay(10);
        setInvestmentFolder(state.investmentFolders[0] || 'Geral');
        setInvestmentMode('NEW');
        if (state.investments.length > 0) {
          setSelectedExistingInvId(state.investments[0].id);
        }
      }
    }
  }, [showAddModal, editingItem, state.cards, state.investmentFolders, state.investments]);

  const handleExport = () => {
    const dataStr = JSON.stringify(state, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
    const exportFileDefaultName = `finance-flow-backup-${new Date().toISOString().split('T')[0]}.json`;
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    setState(db.updateBackupMeta(new Date().toISOString()));
    showToast("Backup exportado com sucesso!");
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const importedData = JSON.parse(event.target?.result as string) as AppState;
        setState(db.restore(importedData));
        showToast("Dados restaurados com sucesso!");
      } catch (err) {
        showToast("Erro ao importar arquivo", "error");
      }
    };
    reader.readAsText(file);
  };

  // TRANSACTION SUBMIT
  const handleTransactionSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const chosenMethod = paymentMethod || (formData.get('paymentMethod') as string);
    const isCredit = chosenMethod === 'Crédito';

    const data: Transaction = {
      id: editingItem?.id || 'tx_' + Math.random().toString(36).substr(2, 9),
      type: transactionType,
      amount: parseFloat(formData.get('amount') as string),
      category: formData.get('category') as string,
      date: transactionDate,
      description: formData.get('description') as string,
      paymentMethod: chosenMethod,
      cardId: isCredit ? (selectedCardId || (formData.get('cardId') as string) || undefined) : undefined,
    };

    if (editingItem) setState(db.updateTransaction(data));
    else setState(db.addTransaction(data));

    showToast(editingItem ? "Transação atualizada!" : "Transação salva!");
    setShowAddModal(false);
    setEditingItem(null);
  };

  // BILL SUBMIT (MULTI-DUE DATES & SUBSCRIPTIONS)
  const handleBillSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const validDueDates = billDueDates.filter(d => !!d);
    const isSubscription = billIsSubscription;
    const subscriptionDay = billSubscriptionDay || 10;

    let finalDueDates = validDueDates;
    if (isSubscription) {
      const now = new Date();
      let targetMonth = now.getMonth();
      let targetYear = now.getFullYear();
      if (now.getDate() > subscriptionDay) {
        targetMonth += 1;
      }
      const subDate = new Date(targetYear, targetMonth, subscriptionDay);
      const y = subDate.getFullYear();
      const m = String(subDate.getMonth() + 1).padStart(2, '0');
      const d = String(subDate.getDate()).padStart(2, '0');
      finalDueDates = [`${y}-${m}-${d}`];
    } else if (finalDueDates.length === 0) {
      finalDueDates = [new Date().toISOString().slice(0, 10)];
    }

    const data: MonthlyBill = {
      id: editingItem?.id || 'bill_' + Math.random().toString(36).substr(2, 9),
      name: formData.get('name') as string,
      amount: parseFloat(formData.get('amount') as string),
      dueDates: finalDueDates,
      paidDueDates: editingItem?.paidDueDates || [],
      isPaid: editingItem?.isPaid || false,
      isSubscription,
      subscriptionDay: isSubscription ? subscriptionDay : undefined,
      category: formData.get('category') as string || 'Moradia',
    };

    if (editingItem) setState(db.updateBill(data));
    else setState(db.addBill(data));

    showToast(isSubscription ? "Assinatura contínua salva!" : "Conta salva!");
    setShowAddModal(false);
    setEditingItem(null);
  };

  // GOAL SUBMIT (SYNC WITH EXPENSES)
  const handleGoalSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const targetAmount = parseFloat(formData.get('targetAmount') as string);
    const currentAmount = parseFloat(formData.get('currentAmount') as string) || 0;

    const data: Goal = {
      id: editingItem?.id || 'goal_' + Math.random().toString(36).substr(2, 9),
      title: formData.get('title') as string,
      targetAmount,
      currentAmount,
      category: formData.get('category') as string,
      deadline: (formData.get('deadline') as string) || undefined,
      notes: (formData.get('notes') as string) || '',
      createdAt: editingItem?.createdAt || new Date().toISOString(),
      status: currentAmount >= targetAmount ? 'COMPLETED' : 'IN_PROGRESS',
      history: editingItem?.history || (currentAmount > 0 ? [{
        id: 'gh_init',
        date: new Date().toISOString(),
        amount: currentAmount,
        type: 'DEPOSIT',
        note: 'Saldo inicial da meta'
      }] : [])
    };

    if (editingItem) {
      setState(db.updateGoal(data));
      showToast("Meta atualizada!");
    } else {
      setState(db.addGoal(data, true));
      showToast(currentAmount > 0 ? "Meta criada e valor debitado dos gastos!" : "Meta salva!");
    }

    setShowAddModal(false);
    setEditingItem(null);
  };

  // INVESTMENT SUBMIT (SYNC WITH EXPENSES)
  const handleInvestmentSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const amount = parseFloat(formData.get('amount') as string);
    const date = (formData.get('date') as string) || new Date().toISOString().slice(0, 10);
    const notes = (formData.get('notes') as string) || '';

    if (investmentMode === 'EXISTING' && selectedExistingInvId) {
      setState(db.aporteToExistingInvestment(selectedExistingInvId, amount, date, notes, true));
      showToast("Aporte adicionado e contabilizado nos gastos!");
    } else {
      const data: Investment = {
        id: editingItem?.id || 'inv_' + Math.random().toString(36).substr(2, 9),
        name: formData.get('name') as string,
        amount,
        date,
        type: formData.get('type') as InvestmentType,
        folder: investmentFolder || 'Geral',
        notes,
      };

      if (editingItem) {
        setState(db.updateInvestment(data));
        showToast("Investimento atualizado!");
      } else {
        setState(db.addInvestment(data, true));
        showToast("Investimento registrado e debitado dos gastos!");
      }
    }

    setShowAddModal(false);
    setEditingItem(null);
  };

  // CARD SUBMIT
  const handleCardSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data: CreditCard = {
      id: editingItem?.id || 'card_' + Math.random().toString(36).substr(2, 9),
      bankName: formData.get('bankName') as string,
      limit: parseFloat(formData.get('limit') as string),
      dueDay: parseInt(formData.get('dueDay') as string),
    };

    if (editingItem) setState(db.updateCard(data));
    else setState(db.addCard(data));

    showToast("Cartão salvo!");
    setShowAddModal(false);
    setEditingItem(null);
  };

  const confirmDelete = () => {
    if (!deletingItem) return;
    if (activeView === 'TRANSACTIONS' || (activeView === 'DASHBOARD' && deletingItem.type)) {
      setState(db.deleteTransaction(deletingItem.id));
    } else if (activeView === 'BILLS') {
      setState(db.deleteBill(deletingItem.id));
    } else if (activeView === 'INVESTMENTS') {
      setState(db.deleteInvestment(deletingItem.id));
    } else if (activeView === 'CARDS') {
      setState(db.deleteCard(deletingItem.id));
    } else if (activeView === 'GOALS') {
      setState(db.deleteGoal(deletingItem.id));
    }
    showToast("Excluído com sucesso!");
    setDeletingItem(null);
  };

  const startEdit = (item: any, type: 'TRANSACTION' | 'BILL' | 'INVESTMENT' | 'CARD' | 'GOAL') => {
    setEditingItem(item);
    setModalType(type);
    setShowAddModal(true);
  };

  return (
    <div className="flex flex-col h-screen max-w-md mx-auto bg-slate-950 text-slate-100 shadow-2xl overflow-hidden relative">
      <input type="file" ref={fileInputRef} className="hidden" accept=".json" onChange={handleImport} />

      {/* Toast Notification */}
      {toast && (
        <div className={`fixed top-20 left-1/2 -translate-x-1/2 z-[160] px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-white text-xs sm:text-sm font-semibold animate-in fade-in zoom-in duration-200 border ${
          toast.type === 'success' ? 'bg-emerald-600 border-emerald-500' : toast.type === 'error' ? 'bg-red-600 border-red-500' : 'bg-indigo-600 border-indigo-500'
        }`}>
          {toast.type === 'success' ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
          {toast.message}
        </div>
      )}

      {/* Header */}
      <header className="p-4 sm:p-5 bg-slate-900 border-b border-slate-800 flex justify-between items-center sticky top-0 z-20">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center font-black text-xs text-white shadow-sm">
              FF
            </div>
            <h1 className="text-lg font-bold text-white tracking-tight">FinanceFlow</h1>
          </div>
          <p className="text-[10px] text-slate-400 uppercase font-semibold tracking-wider mt-0.5">
            {new Date().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}
          </p>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Notifications button with badge */}
          <button 
            onClick={() => setShowNotificationsModal(true)} 
            className="relative p-2 bg-slate-800 text-slate-300 rounded-xl hover:bg-slate-700 transition-colors" 
            title="Avisos e Vencimentos"
          >
            <Bell size={17} />
            {notificationCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 bg-red-600 text-white text-[10px] font-extrabold rounded-full flex items-center justify-center shadow-md animate-pulse">
                {notificationCount > 9 ? '9+' : notificationCount}
              </span>
            )}
          </button>

          <button 
            onClick={() => setShowAutoIncomeModal(true)} 
            className="p-2 bg-emerald-950/40 text-emerald-400 hover:bg-emerald-900/60 rounded-xl border border-emerald-800/40 transition-colors" 
            title="Saldo Automático em Caixa"
          >
            <Zap size={17} />
          </button>
          <button onClick={handleExport} className="p-2 bg-slate-800 text-slate-300 rounded-xl hover:bg-slate-700 transition-colors" title="Exportar Backup">
            <Download size={17} />
          </button>
          <button onClick={() => fileInputRef.current?.click()} className="p-2 bg-slate-800 text-slate-300 rounded-xl hover:bg-slate-700 transition-colors" title="Importar Backup">
            <Upload size={17} />
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-4 space-y-5 pb-24">
        
        {/* DASHBOARD VIEW */}
        {activeView === 'DASHBOARD' && (
          <>
            {/* Saldo em Caixa Card */}
            <div className="bg-gradient-to-br from-indigo-600 via-indigo-700 to-indigo-900 p-5 rounded-3xl text-white shadow-xl shadow-indigo-950/50 relative overflow-hidden">
              <div className="absolute right-0 top-0 w-32 h-32 bg-white/5 rounded-full blur-xl pointer-events-none" />
              <div className="flex justify-between items-center">
                <span className="text-indigo-200 text-xs font-bold uppercase tracking-wider">Saldo em Caixa</span>
                <button
                  onClick={() => setShowAutoIncomeModal(true)}
                  className="text-[10px] bg-white/20 hover:bg-white/30 text-white px-2.5 py-1 rounded-full font-bold flex items-center gap-1 backdrop-blur-sm"
                >
                  <Zap size={11} /> Saldo Automático
                </button>
              </div>
              <div className="text-3xl font-extrabold mt-1">
                R$ {stats.balance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </div>

              <div className="grid grid-cols-2 gap-2.5 mt-5">
                <div className="bg-black/20 p-2.5 rounded-2xl backdrop-blur-sm border border-white/10">
                  <span className="text-[10px] uppercase font-bold text-emerald-300 block">Receitas</span>
                  <div className="font-bold text-sm text-white">R$ {stats.income.toFixed(2)}</div>
                </div>
                <div className="bg-black/20 p-2.5 rounded-2xl backdrop-blur-sm border border-white/10">
                  <span className="text-[10px] uppercase font-bold text-red-300 block">Gastos Totais</span>
                  <div className="font-bold text-sm text-white">R$ {stats.expenses.toFixed(2)}</div>
                </div>
              </div>
            </div>

            {/* Quick Metrics Grid */}
            <div className="grid grid-cols-3 gap-2.5">
              <div 
                onClick={() => setActiveView('BILLS')} 
                className="bg-slate-900 p-3 rounded-2xl border border-slate-800 cursor-pointer hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center gap-1.5 mb-1 text-red-400">
                  <Calendar size={14} />
                  <span className="text-[10px] font-bold uppercase">Contas</span>
                </div>
                <div className="text-sm font-bold text-slate-100">R$ {stats.billsPending.toFixed(2)}</div>
              </div>

              <div 
                onClick={() => setActiveView('CARDS')} 
                className="bg-slate-900 p-3 rounded-2xl border border-slate-800 cursor-pointer hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center gap-1.5 mb-1 text-amber-400">
                  <CardIcon size={14} />
                  <span className="text-[10px] font-bold uppercase">Faturas</span>
                </div>
                <div className="text-sm font-bold text-slate-100">R$ {stats.totalCardsDebt.toFixed(2)}</div>
              </div>

              <div 
                onClick={() => setActiveView('GOALS')} 
                className="bg-slate-900 p-3 rounded-2xl border border-slate-800 cursor-pointer hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center gap-1.5 mb-1 text-indigo-400">
                  <Target size={14} />
                  <span className="text-[10px] font-bold uppercase">Metas</span>
                </div>
                <div className="text-sm font-bold text-slate-100">R$ {stats.goalsTotal.toFixed(2)}</div>
              </div>
            </div>

            {/* Recent Transactions Section */}
            <div>
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-bold text-slate-100 text-sm sm:text-base">Lançamentos Recentes</h3>
                <button 
                  onClick={() => setActiveView('TRANSACTIONS')} 
                  className="text-indigo-400 hover:text-indigo-300 text-xs font-bold flex items-center gap-0.5"
                >
                  Ver tudo <ChevronRight size={14} />
                </button>
              </div>
              <div className="space-y-2.5">
                {state.transactions.slice(0, 5).map(tx => (
                  <TransactionListItem 
                    key={tx.id} 
                    tx={tx} 
                    cards={state.cards}
                    onEdit={() => startEdit(tx, 'TRANSACTION')} 
                    onDelete={() => setDeletingItem(tx)} 
                  />
                ))}
                {state.transactions.length === 0 && (
                  <div className="text-center py-10 text-slate-600 text-xs">
                    Nenhuma transação registrada.
                  </div>
                )}
              </div>
            </div>
          </>
        )}

        {/* TRANSACTIONS VIEW (WITH ADVANCED FILTERS AND RULES) */}
        {activeView === 'TRANSACTIONS' && (
          <TransactionsView
            transactions={state.transactions}
            cards={state.cards}
            onOpenAddModal={() => {
              setEditingItem(null);
              setModalType('TRANSACTION');
              setShowAddModal(true);
            }}
            onStartEdit={(tx) => startEdit(tx, 'TRANSACTION')}
            onStartDelete={(tx) => setDeletingItem(tx)}
          />
        )}

        {/* BILLS VIEW */}
        {activeView === 'BILLS' && (
          <BillsView
            bills={state.bills}
            paidHistory={state.paidBillsHistory}
            deletedHistory={state.deletedBillsHistory}
            retentionSettings={state.retentionSettings}
            onToggleDueDate={(billId, date) => setState(db.toggleBillDueDate(billId, date))}
            onArchiveBill={(billId) => setState(db.archivePaidBill(billId))}
            onRestorePaid={(id) => setState(db.restorePaidBill(id))}
            onDeletePaid={(id) => setState(db.deletePaidBillFromHistory(id))}
            onClearPaidHistory={() => setState(db.clearPaidBillsHistory())}
            onRestoreDeleted={(id) => setState(db.restoreDeletedBill(id))}
            onDeleteDeletedPermanently={(id) => setState(db.deletePermanentlyFromTrash(id))}
            onClearDeletedHistory={() => setState(db.clearDeletedBillsHistory())}
            onUpdateRetention={(settings) => setState(db.updateRetentionSettings(settings))}
            onStartEdit={(bill) => startEdit(bill, 'BILL')}
            onStartDelete={(bill) => setDeletingItem(bill)}
            onOpenAddModal={() => {
              setEditingItem(null);
              setModalType('BILL');
              setShowAddModal(true);
            }}
          />
        )}

        {/* CARDS VIEW */}
        {activeView === 'CARDS' && (
          <CardsView
            cards={state.cards}
            transactions={state.transactions}
            paidCardInvoices={state.paidCardInvoices}
            onOpenAddModal={() => {
              setEditingItem(null);
              setModalType('CARD');
              setShowAddModal(true);
            }}
            onStartEdit={(card) => startEdit(card, 'CARD')}
            onStartDelete={(card) => setDeletingItem(card)}
            onPayInvoice={(cardId, amount, total, debitCash) => {
              setState(db.payCardInvoice(cardId, amount, total, debitCash));
              showToast("Fatura paga! Limite restabelecido.");
            }}
            onUpdatePaidInvoice={(invoiceId, newAmount, newDate) => {
              setState(db.updatePaidCardInvoice(invoiceId, newAmount, newDate));
              showToast("Fatura paga atualizada com sucesso!");
            }}
            onDeletePaidInvoice={(invoiceId) => {
              setState(db.deletePaidCardInvoice(invoiceId));
              showToast("Fatura removida do histórico!");
            }}
          />
        )}

        {/* GOALS VIEW */}
        {activeView === 'GOALS' && (
          <GoalsView
            goals={state.goals}
            onOpenAddGoalModal={() => {
              setEditingItem(null);
              setModalType('GOAL');
              setShowAddModal(true);
            }}
            onStartEditGoal={(goal) => startEdit(goal, 'GOAL')}
            onStartDeleteGoal={(goal) => setDeletingItem(goal)}
            onToggleFocus={(goalId) => {
              setState(db.toggleGoalFocus(goalId));
            }}
            onContribute={(goalId, amount, type, note, debitCash) => {
              setState(db.contributeToGoal(goalId, amount, type, note, debitCash));
              showToast(type === 'DEPOSIT' ? "Aporte realizado!" : "Resgate realizado!");
            }}
          />
        )}

        {/* INVESTMENTS VIEW */}
        {activeView === 'INVESTMENTS' && (
          <InvestmentsView
            investments={state.investments}
            folders={state.investmentFolders}
            onOpenAddModal={() => {
              setEditingItem(null);
              setModalType('INVESTMENT');
              setShowAddModal(true);
            }}
            onStartEdit={(inv) => startEdit(inv, 'INVESTMENT')}
            onStartDelete={(inv) => setDeletingItem(inv)}
            onAddFolder={(folder) => setState(db.addInvestmentFolder(folder))}
            onDeleteFolder={(folder) => setState(db.deleteInvestmentFolder(folder))}
          />
        )}

      </main>

      {/* Floating Action Button (FAB) */}
      <div className="fixed bottom-20 right-5 z-30">
        <button 
          onClick={() => {
            setEditingItem(null);
            if (activeView === 'DASHBOARD' || activeView === 'TRANSACTIONS') setModalType('TRANSACTION');
            else if (activeView === 'BILLS') setModalType('BILL');
            else if (activeView === 'CARDS') setModalType('CARD');
            else if (activeView === 'GOALS') setModalType('GOAL');
            else setModalType('INVESTMENT');
            setShowAddModal(true);
          }}
          className="w-14 h-14 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full shadow-2xl flex items-center justify-center active:scale-95 transition-transform"
        >
          <Plus size={28} />
        </button>
      </div>

      {/* Bottom Navigation */}
      <nav className="bg-slate-900 border-t border-slate-800 px-3 py-2 pb-5 flex justify-around items-center sticky bottom-0 z-30 shadow-[0_-4px_20px_rgba(0,0,0,0.5)]">
        <NavButton label="Início" active={activeView === 'DASHBOARD'} icon={<LayoutDashboard size={20} />} onClick={() => setActiveView('DASHBOARD')} />
        <NavButton label="Gastos" active={activeView === 'TRANSACTIONS'} icon={<Wallet size={20} />} onClick={() => setActiveView('TRANSACTIONS')} />
        <NavButton label="Cartões" active={activeView === 'CARDS'} icon={<CardIcon size={20} />} onClick={() => setActiveView('CARDS')} />
        <NavButton label="Contas" active={activeView === 'BILLS'} icon={<Calendar size={20} />} onClick={() => setActiveView('BILLS')} />
        <NavButton label="Metas" active={activeView === 'GOALS'} icon={<Target size={20} />} onClick={() => setActiveView('GOALS')} />
        <NavButton label="Ativos" active={activeView === 'INVESTMENTS'} icon={<TrendingUp size={20} />} onClick={() => setActiveView('INVESTMENTS')} />
      </nav>

      {/* DELETE CONFIRMATION MODAL */}
      {deletingItem && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[150] flex items-center justify-center p-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-xs text-center animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 bg-red-950/40 text-red-500 rounded-full flex items-center justify-center mx-auto mb-3 border border-red-900/50">
              <Trash2 size={26} />
            </div>
            <h3 className="text-lg font-bold text-slate-100 mb-1">Excluir?</h3>
            <p className="text-xs text-slate-400 mb-6">
              {activeView === 'BILLS' 
                ? 'Esta conta irá para o histórico de excluídas (Lixeira vitalícia).' 
                : 'Tem certeza que deseja remover este registro?'}
            </p>
            <div className="flex gap-2">
              <button 
                onClick={() => setDeletingItem(null)} 
                className="flex-1 py-2.5 bg-slate-800 text-slate-300 rounded-xl font-bold text-xs"
              >
                Cancelar
              </button>
              <button 
                onClick={confirmDelete} 
                className="flex-1 py-2.5 bg-red-600 text-white rounded-xl font-bold text-xs"
              >
                Excluir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AUTO INCOME MODAL */}
      <AutoIncomeModal
        isOpen={showAutoIncomeModal}
        onClose={() => setShowAutoIncomeModal(false)}
        rules={state.autoIncomeRules}
        onAddRule={(rule) => {
          setState(db.addAutoIncomeRule(rule));
          showToast("Regra cadastrada!");
        }}
        onUpdateRule={(rule) => {
          setState(db.updateAutoIncomeRule(rule));
          showToast("Regra atualizada com sucesso!");
        }}
        onToggleRule={(id) => setState(db.toggleAutoIncomeRule(id))}
        onDeleteRule={(id) => setState(db.deleteAutoIncomeRule(id))}
      />

      {/* CRUD MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-[140] flex flex-col justify-end sm:justify-center sm:p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-t-[32px] sm:rounded-3xl p-6 max-h-[90vh] overflow-y-auto animate-in slide-in-from-bottom duration-200">
            <div className="flex justify-between items-center mb-5">
              <h2 className="text-xl font-bold text-slate-100">
                {editingItem ? 'Editar ' : 'Novo '}
                {modalType === 'TRANSACTION' ? 'Lançamento' : modalType === 'BILL' ? 'Conta Mensal' : modalType === 'CARD' ? 'Cartão' : modalType === 'GOAL' ? 'Meta / Objetivo' : 'Investimento'}
              </h2>
              <button 
                onClick={() => { setShowAddModal(false); setEditingItem(null); }} 
                className="p-1.5 bg-slate-800 rounded-full text-slate-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            {/* TRANSACTION FORM */}
            {modalType === 'TRANSACTION' && (
              <form onSubmit={handleTransactionSubmit} className="space-y-4">
                {/* Type selection */}
                <div className="flex gap-2 p-1 bg-slate-800 rounded-2xl">
                  <button
                    type="button"
                    onClick={() => setTransactionType('EXPENSE')}
                    className={`flex-1 py-2 text-center rounded-xl text-xs font-bold transition-all ${
                      transactionType === 'EXPENSE' ? 'bg-red-600 text-white shadow' : 'text-slate-400'
                    }`}
                  >
                    Despesa
                  </button>
                  <button
                    type="button"
                    onClick={() => setTransactionType('INCOME')}
                    className={`flex-1 py-2 text-center rounded-xl text-xs font-bold transition-all ${
                      transactionType === 'INCOME' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400'
                    }`}
                  >
                    Receita
                  </button>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Valor (R$)</label>
                  <input 
                    name="amount" 
                    type="number" 
                    step="0.01" 
                    required 
                    defaultValue={editingItem?.amount} 
                    className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl text-xl font-bold text-white focus:outline-none focus:border-indigo-500" 
                    placeholder="0,00" 
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Método de Pagamento</label>
                  <select 
                    name="paymentMethod" 
                    required 
                    value={paymentMethod} 
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-semibold text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                  >
                    <option value="" disabled>Selecione...</option>
                    <option value="Dinheiro / Pix">Dinheiro / Pix</option>
                    <option value="Cartão de Débito">Cartão de Débito</option>
                    <option value="Crédito">Cartão de Crédito</option>
                    <option value="Boleto">Boleto Bancário</option>
                  </select>
                </div>

                {/* If Credit is selected, user must pick which Credit Card to link */}
                {paymentMethod === 'Crédito' && (
                  <div className="bg-indigo-950/40 p-3.5 rounded-2xl border border-indigo-900/40 space-y-2">
                    <label className="text-xs font-bold text-indigo-300 uppercase tracking-wider block">
                      Vincular ao Cartão (Descontará do Limite)
                    </label>
                    {state.cards.length === 0 ? (
                      <div className="text-xs text-amber-400">
                        Nenhum cartão cadastrado ainda. Cadastre um cartão na aba Cartões para descontar do limite!
                      </div>
                    ) : (
                      <select 
                        name="cardId" 
                        required 
                        value={selectedCardId} 
                        onChange={(e) => setSelectedCardId(e.target.value)}
                        className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl font-bold text-white text-sm focus:outline-none focus:border-indigo-500"
                      >
                        {state.cards.map(c => (
                          <option key={c.id} value={c.id}>
                            {c.bankName} (Vence dia {c.dueDay})
                          </option>
                        ))}
                      </select>
                    )}
                  </div>
                )}

                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Categoria</label>
                  <input 
                    name="category" 
                    list="categories-list" 
                    required 
                    defaultValue={editingItem?.category || 'Alimentação'} 
                    className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-semibold text-slate-100 text-sm focus:outline-none focus:border-indigo-500" 
                    placeholder="Ex: Alimentação, Transporte..." 
                  />
                  <datalist id="categories-list">
                    {CATEGORIES.map(c => <option key={c.id} value={c.id} />)}
                  </datalist>
                </div>

                {/* Keyboard & Mobile friendly Date & Time Input */}
                <MobileDateTimeInput
                  value={transactionDate}
                  onChange={setTransactionDate}
                  required
                />

                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Descrição</label>
                  <input 
                    name="description" 
                    type="text" 
                    defaultValue={editingItem?.description} 
                    className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-semibold text-slate-100 text-sm focus:outline-none focus:border-indigo-500" 
                    placeholder="Ex: Mercado mensal, Café..." 
                  />
                </div>

                <button 
                  type="submit" 
                  className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-3.5 rounded-2xl font-bold text-base shadow-lg active:scale-95 transition-all mt-2"
                >
                  Salvar Lançamento
                </button>
              </form>
            )}

            {/* BILL FORM (MULTI-DUE DATES & SUBSCRIPTIONS) */}
            {modalType === 'BILL' && (
              <form onSubmit={handleBillSubmit} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Nome da Conta / Serviço</label>
                  <input 
                    name="name" 
                    type="text" 
                    required 
                    defaultValue={editingItem?.name} 
                    placeholder="Ex: Netflix, Internet, Aluguel, Curso..." 
                    className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-bold text-white text-sm focus:outline-none focus:border-indigo-500" 
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Categoria</label>
                  <input 
                    name="category" 
                    list="categories-list" 
                    defaultValue={editingItem?.category || 'Moradia'} 
                    className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-semibold text-slate-100 text-sm focus:outline-none focus:border-indigo-500" 
                    placeholder="Ex: Moradia, Lazer, Compras..." 
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Valor Mensal (R$)</label>
                  <input 
                    name="amount" 
                    type="number" 
                    step="0.01" 
                    required 
                    defaultValue={editingItem?.amount} 
                    placeholder="0,00"
                    className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl text-xl font-bold text-white focus:outline-none focus:border-indigo-500" 
                  />
                </div>

                {/* Tipo de Cobrança: Parcelas vs Assinatura Contínua Vitalícia */}
                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Tipo de Cobrança
                  </label>
                  <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 rounded-2xl border border-slate-800">
                    <button
                      type="button"
                      onClick={() => setBillIsSubscription(false)}
                      className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all text-center flex flex-col items-center justify-center gap-1 ${
                        !billIsSubscription ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <Calendar size={15} />
                      <span>Conta / Parcelas</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setBillIsSubscription(true)}
                      className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all text-center flex flex-col items-center justify-center gap-1 ${
                        billIsSubscription ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <Repeat size={15} />
                      <span>Assinatura Vitalícia</span>
                    </button>
                  </div>
                </div>

                {/* SUBSCRIPTION MODE */}
                {billIsSubscription ? (
                  <div className="bg-indigo-950/30 p-3.5 rounded-2xl border border-indigo-800/40 space-y-3">
                    <div className="flex items-start gap-2 text-indigo-300 text-xs">
                      <Repeat size={16} className="text-indigo-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-bold text-indigo-200">Assinatura Mensal Contínua (Vitalícia)</p>
                        <p className="text-[11px] text-indigo-300/80 mt-0.5">
                          Não precisa definir prazo ou 12 meses. Ao pagar o mês, ela vai automaticamente para o final da fila com o vencimento do mês seguinte.
                        </p>
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1">
                        Dia do Vencimento Todo Mês
                      </label>
                      <select
                        value={billSubscriptionDay}
                        onChange={(e) => setBillSubscriptionDay(parseInt(e.target.value))}
                        className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl font-bold text-white text-sm focus:outline-none focus:border-indigo-500"
                      >
                        {Array.from({ length: 31 }, (_, i) => i + 1).map(day => (
                          <option key={day} value={day}>
                            Todo dia {day} de cada mês
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                ) : (
                  /* STANDARD MULTI-DUE DATES UI */
                  <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-3">
                    <div>
                      <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                        Vencimentos ({billDueDates.length} parcela{billDueDates.length > 1 ? 's' : ''})
                      </label>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Adicione mais parcelas mensais consecutivas ou datas no mesmo mês:
                      </p>
                    </div>

                    {/* Select to add months / installments */}
                    <div className="flex gap-2 items-center">
                      <select
                        onChange={(e) => {
                          const val = e.target.value;
                          if (!val) return;
                          const baseStr = billDueDates[billDueDates.length - 1] || new Date().toISOString().slice(0, 10);
                          const parts = baseStr.split('-');
                          const year = parseInt(parts[0]);
                          const month = parseInt(parts[1]) - 1;
                          const day = parseInt(parts[2]);

                          if (val === 'SAME_MONTH') {
                            setBillDueDates(prev => [...prev, new Date().toISOString().slice(0, 10)]);
                          } else {
                            const count = parseInt(val);
                            const generated: string[] = [];
                            for (let i = 1; i <= count; i++) {
                              const d = new Date(year, month + i, day);
                              const y = d.getFullYear();
                              const m = String(d.getMonth() + 1).padStart(2, '0');
                              const dayFormatted = String(d.getDate()).padStart(2, '0');
                              generated.push(`${y}-${m}-${dayFormatted}`);
                            }
                            setBillDueDates(prev => [...prev, ...generated]);
                          }
                          e.target.value = '';
                        }}
                        className="w-full bg-indigo-950/50 border border-indigo-800/40 p-2.5 rounded-xl font-bold text-indigo-300 text-xs focus:outline-none"
                      >
                        <option value="">➕ Selecionar: Adicionar parcelas / meses...</option>
                        <option value="SAME_MONTH">+ 1 vencimento no mesmo mês</option>
                        <option value="1">+ 1 mês (+1 parcela)</option>
                        <option value="2">+ 2 meses (+2 parcelas)</option>
                        <option value="3">+ 3 meses (+3 parcelas)</option>
                        <option value="5">+ 5 meses (+5 parcelas)</option>
                        <option value="6">+ 6 meses (semestral)</option>
                        <option value="10">+ 10 meses (+10 parcelas)</option>
                        <option value="12">+ 12 meses (1 ano inteiro)</option>
                      </select>
                    </div>

                    <div className="space-y-2 pt-1 max-h-48 overflow-y-auto pr-1">
                      {billDueDates.map((d, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <span className="text-xs text-slate-400 font-bold w-5">{index + 1}º</span>
                          <input
                            type="date"
                            required
                            value={d}
                            onChange={(e) => {
                              const val = e.target.value;
                              setBillDueDates(prev => {
                                const copy = [...prev];
                                copy[index] = val;
                                return copy;
                              });
                            }}
                            className="flex-1 bg-slate-800 border border-slate-700 p-2.5 rounded-xl font-bold text-white text-xs focus:outline-none focus:border-indigo-500"
                          />
                          {billDueDates.length > 1 && (
                            <button
                              type="button"
                              onClick={() => setBillDueDates(prev => prev.filter((_, i) => i !== index))}
                              className="p-2 text-red-400 hover:text-red-300"
                              title="Remover parcela"
                            >
                              <Trash2 size={15} />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <button 
                  type="submit" 
                  className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-3.5 rounded-2xl font-bold text-base shadow-lg active:scale-95 transition-all mt-2"
                >
                  Salvar Conta
                </button>
              </form>
            )}

            {/* GOAL FORM */}
            {modalType === 'GOAL' && (
              <form onSubmit={handleGoalSubmit} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Título da Meta</label>
                  <input 
                    name="title" 
                    type="text" 
                    required 
                    defaultValue={editingItem?.title} 
                    placeholder="Ex: Placa de Vídeo, Guarda-Roupa, Viagem..." 
                    className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-bold text-white text-sm focus:outline-none focus:border-indigo-500" 
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Categoria da Meta</label>
                  <select
                    name="category"
                    required
                    defaultValue={editingItem?.category || GOAL_CATEGORIES[0].id}
                    className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-semibold text-white text-sm focus:outline-none focus:border-indigo-500"
                  >
                    {GOAL_CATEGORIES.map(c => (
                      <option key={c.id} value={c.id}>{c.id}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Valor Alvo (R$)</label>
                    <input 
                      name="targetAmount" 
                      type="number" 
                      step="0.01" 
                      required 
                      defaultValue={editingItem?.targetAmount} 
                      placeholder="0,00"
                      className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl font-bold text-white text-base focus:outline-none focus:border-indigo-500" 
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Já Poupado (R$)</label>
                    <input 
                      name="currentAmount" 
                      type="number" 
                      step="0.01" 
                      defaultValue={editingItem?.currentAmount || 0} 
                      placeholder="0,00"
                      className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl font-bold text-white text-base focus:outline-none focus:border-indigo-500" 
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Prazo Estimado (Opcional)</label>
                  <input 
                    name="deadline" 
                    type="date" 
                    defaultValue={editingItem?.deadline} 
                    className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl font-bold text-white text-xs focus:outline-none focus:border-indigo-500" 
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Notas / Motivação</label>
                  <input 
                    name="notes" 
                    type="text" 
                    defaultValue={editingItem?.notes} 
                    placeholder="Ex: Modelo específico ou link de compra..." 
                    className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500" 
                  />
                </div>

                <button 
                  type="submit" 
                  className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-3.5 rounded-2xl font-bold text-base shadow-lg active:scale-95 transition-all mt-2"
                >
                  Salvar Meta
                </button>
              </form>
            )}

            {/* CARD FORM */}
            {modalType === 'CARD' && (
              <form onSubmit={handleCardSubmit} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Banco / Nome do Cartão</label>
                  <input 
                    name="bankName" 
                    type="text" 
                    required 
                    defaultValue={editingItem?.bankName} 
                    placeholder="Ex: Nubank, Inter, Itaú..." 
                    className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-bold text-white text-sm focus:outline-none focus:border-indigo-500" 
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Limite Total do Cartão (R$)</label>
                  <input 
                    name="limit" 
                    type="number" 
                    step="0.01" 
                    required 
                    defaultValue={editingItem?.limit} 
                    placeholder="0,00"
                    className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl text-xl font-bold text-white focus:outline-none focus:border-indigo-500" 
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Dia do Vencimento da Fatura</label>
                  <input 
                    name="dueDay" 
                    type="number" 
                    min="1" 
                    max="31" 
                    required 
                    defaultValue={editingItem?.dueDay || 10} 
                    className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-bold text-white text-sm focus:outline-none focus:border-indigo-500" 
                  />
                </div>

                <button 
                  type="submit" 
                  className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-3.5 rounded-2xl font-bold text-base shadow-lg active:scale-95 transition-all mt-2"
                >
                  Salvar Cartão
                </button>
              </form>
            )}

            {/* INVESTMENT FORM */}
            {modalType === 'INVESTMENT' && (
              <form onSubmit={handleInvestmentSubmit} className="space-y-4">
                {/* Mode toggle if investments exist and not editing */}
                {!editingItem && state.investments.length > 0 && (
                  <div className="flex gap-2 p-1 bg-slate-800 rounded-2xl">
                    <button
                      type="button"
                      onClick={() => setInvestmentMode('NEW')}
                      className={`flex-1 py-2 text-center rounded-xl text-xs font-bold transition-all ${
                        investmentMode === 'NEW' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400'
                      }`}
                    >
                      Novo Ativo
                    </button>
                    <button
                      type="button"
                      onClick={() => setInvestmentMode('EXISTING')}
                      className={`flex-1 py-2 text-center rounded-xl text-xs font-bold transition-all ${
                        investmentMode === 'EXISTING' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400'
                      }`}
                    >
                      Aporte em Ativo Existente
                    </button>
                  </div>
                )}

                {investmentMode === 'EXISTING' && !editingItem ? (
                  <>
                    <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-2">
                      <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                        Selecione o Ativo para Somar o Aporte
                      </label>
                      <select
                        value={selectedExistingInvId}
                        onChange={(e) => setSelectedExistingInvId(e.target.value)}
                        className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-bold text-white text-sm focus:outline-none focus:border-indigo-500"
                      >
                        {state.investments.map(inv => (
                          <option key={inv.id} value={inv.id}>
                            {inv.name} (Atual: R$ {inv.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}) • {inv.folder || 'Geral'}
                          </option>
                        ))}
                      </select>
                      <p className="text-[11px] text-slate-400">
                        O novo valor será totalizado no mesmo ativo, evitando cadastros duplicados.
                      </p>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                        Valor do Novo Aporte (R$)
                      </label>
                      <input 
                        name="amount" 
                        type="number" 
                        step="0.01" 
                        required 
                        placeholder="0,00"
                        className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl text-xl font-bold text-white focus:outline-none focus:border-indigo-500" 
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                        Data do Aporte
                      </label>
                      <input 
                        name="date" 
                        type="date" 
                        required 
                        defaultValue={new Date().toISOString().slice(0, 10)} 
                        className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-bold text-white text-xs focus:outline-none focus:border-indigo-500" 
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                        Observação do Aporte (Opcional)
                      </label>
                      <input 
                        name="notes" 
                        type="text" 
                        placeholder="Ex: Compra mensal na baixa, corretora..." 
                        className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500" 
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Pasta / Grupo do Ativo</label>
                      <select 
                        value={investmentFolder} 
                        onChange={e => setInvestmentFolder(e.target.value)}
                        className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-bold text-white text-sm focus:outline-none focus:border-indigo-500"
                      >
                        {state.investmentFolders.map(f => (
                          <option key={f} value={f}>📁 {f}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Tipo de Ativo</label>
                      <select 
                        name="type" 
                        required 
                        defaultValue={editingItem?.type || 'CRYPTOCURRENCY'} 
                        className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-semibold text-white text-sm focus:outline-none focus:border-indigo-500"
                      >
                        {INVESTMENT_TYPES.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Nome / Código do Ativo</label>
                      <input 
                        name="name" 
                        type="text" 
                        required 
                        defaultValue={editingItem?.name} 
                        placeholder="Ex: Bitcoin (BTC), PETR4, Tesouro Selic..." 
                        className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-bold text-white text-sm focus:outline-none focus:border-indigo-500" 
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Valor Investido (R$)</label>
                      <input 
                        name="amount" 
                        type="number" 
                        step="0.01" 
                        required 
                        defaultValue={editingItem?.amount} 
                        className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl text-xl font-bold text-white focus:outline-none focus:border-indigo-500" 
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Data do Aporte</label>
                      <input 
                        name="date" 
                        type="date" 
                        required 
                        defaultValue={editingItem?.date || new Date().toISOString().slice(0, 10)} 
                        className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-bold text-white text-xs focus:outline-none focus:border-indigo-500" 
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Notas / Detalhes</label>
                      <input 
                        name="notes" 
                        type="text" 
                        defaultValue={editingItem?.notes} 
                        placeholder="Ex: Corretora, taxa, carteira fria..." 
                        className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500" 
                      />
                    </div>
                  </>
                )}

                <button 
                  type="submit" 
                  className={`w-full text-white py-3.5 rounded-2xl font-bold text-base shadow-lg active:scale-95 transition-all mt-2 ${
                    investmentMode === 'EXISTING' && !editingItem ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-indigo-600 hover:bg-indigo-500'
                  }`}
                >
                  {investmentMode === 'EXISTING' && !editingItem ? 'Salvar Aporte no Ativo' : 'Salvar Ativo'}
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* NOTIFICATIONS MODAL */}
      <NotificationsModal
        isOpen={showNotificationsModal}
        onClose={() => setShowNotificationsModal(false)}
        bills={state.bills}
        cards={state.cards}
        dismissedIds={state.dismissedNotificationIds || []}
        onDismissNotification={(id) => setState(db.dismissNotification(id))}
        onClearAllNotifications={(ids) => setState(db.clearAllNotifications(ids))}
        onNavigateToBills={() => {
          setShowNotificationsModal(false);
          setActiveView('BILLS');
        }}
        onNavigateToCards={() => {
          setShowNotificationsModal(false);
          setActiveView('CARDS');
        }}
      />
    </div>
  );
};

const TransactionListItem: React.FC<{ 
  tx: Transaction; 
  cards: CreditCard[];
  onEdit: () => void; 
  onDelete: () => void; 
}> = ({ tx, cards, onEdit, onDelete }) => {
  const linkedCard = tx.cardId ? cards.find(c => c.id === tx.cardId) : null;

  return (
    <div className="bg-slate-900 p-3.5 rounded-2xl border border-slate-800 flex items-center justify-between group hover:border-slate-700 transition-colors">
      <div className="flex items-center gap-3 overflow-hidden mr-2">
        <div className={`w-9 h-9 shrink-0 rounded-xl flex items-center justify-center border ${
          tx.type === 'INCOME' 
            ? 'bg-emerald-950/40 text-emerald-400 border-emerald-800/40' 
            : 'bg-red-950/40 text-red-400 border-red-800/40'
        }`}>
          {CATEGORIES.find(c => c.id === tx.category)?.icon || <Wallet size={16} />}
        </div>
        <div className="overflow-hidden">
          <div className="text-sm font-bold text-slate-100 truncate">
            {tx.description || tx.category}
          </div>
          <div className="text-[10px] text-slate-400 flex items-center gap-1 font-medium">
            {new Date(tx.date).toLocaleDateString('pt-BR')} • {tx.paymentMethod}
            {linkedCard && (
              <span className="text-indigo-400 font-semibold">({linkedCard.bankName})</span>
            )}
            {tx.isAutoIncome && (
              <span className="bg-emerald-950 text-emerald-300 px-1 rounded text-[9px] font-bold">Auto</span>
            )}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <div className={`text-sm font-bold text-right ${tx.type === 'INCOME' ? 'text-emerald-400' : 'text-slate-200'}`}>
          {tx.type === 'INCOME' ? '+' : '-'} R$ {tx.amount.toFixed(2)}
        </div>
        <div className="flex items-center gap-1">
          <button onClick={onEdit} className="p-1 text-slate-500 hover:text-indigo-400">
            <Edit2 size={12} />
          </button>
          <button onClick={onDelete} className="p-1 text-slate-500 hover:text-red-400">
            <Trash2 size={12} />
          </button>
        </div>
      </div>
    </div>
  );
};

const NavButton: React.FC<{ 
  label: string; 
  active: boolean; 
  icon: React.ReactNode; 
  onClick: () => void; 
}> = ({ label, active, icon, onClick }) => (
  <button 
    onClick={onClick} 
    className={`flex flex-col items-center gap-0.5 px-2 py-1 rounded-xl transition-all ${
      active 
        ? 'text-indigo-400 scale-105 font-bold' 
        : 'text-slate-400 hover:text-slate-200 font-medium'
    }`}
  >
    <div className={`p-1.5 rounded-xl ${active ? 'bg-indigo-950/70 border border-indigo-800/40 text-indigo-400' : ''}`}>
      {icon}
    </div>
    <span className="text-[10px] tracking-tight">{label}</span>
  </button>
);

export default App;
