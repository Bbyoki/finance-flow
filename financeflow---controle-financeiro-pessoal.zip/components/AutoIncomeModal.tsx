import React, { useState } from 'react';
import { X, Plus, Trash2, Calendar, Check, Power, Edit2 } from 'lucide-react';
import { AutoIncomeRule } from '../types';

interface AutoIncomeModalProps {
  isOpen: boolean;
  onClose: () => void;
  rules: AutoIncomeRule[];
  onAddRule: (rule: AutoIncomeRule) => void;
  onUpdateRule: (rule: AutoIncomeRule) => void;
  onToggleRule: (id: string) => void;
  onDeleteRule: (id: string) => void;
}

export const AutoIncomeModal: React.FC<AutoIncomeModalProps> = ({
  isOpen,
  onClose,
  rules,
  onAddRule,
  onUpdateRule,
  onToggleRule,
  onDeleteRule
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);

  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [selectedDays, setSelectedDays] = useState<number[]>([10, 20]);
  const [category, setCategory] = useState('Trabalho / Salário');

  if (!isOpen) return null;

  const toggleDay = (day: number) => {
    setSelectedDays(prev => 
      prev.includes(day) 
        ? prev.filter(d => d !== day) 
        : [...prev, day].sort((a, b) => a - b)
    );
  };

  const startEditRule = (rule: AutoIncomeRule) => {
    setEditingRuleId(rule.id);
    setName(rule.name);
    setAmount(rule.amount.toString());
    setSelectedDays(rule.daysOfMonth || [10, 20]);
    setCategory(rule.category || 'Trabalho / Salário');
    setShowAddForm(true);
  };

  const resetForm = () => {
    setName('');
    setAmount('');
    setSelectedDays([10, 20]);
    setCategory('Trabalho / Salário');
    setEditingRuleId(null);
    setShowAddForm(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !amount || selectedDays.length === 0) return;

    if (editingRuleId) {
      const existing = rules.find(r => r.id === editingRuleId);
      const updated: AutoIncomeRule = {
        id: editingRuleId,
        name,
        amount: parseFloat(amount),
        daysOfMonth: selectedDays,
        category,
        paymentMethod: existing?.paymentMethod || 'Dinheiro / Pix',
        active: existing ? existing.active : true,
        processedDays: existing?.processedDays || {}
      };
      onUpdateRule(updated);
    } else {
      const newRule: AutoIncomeRule = {
        id: 'rule_' + Math.random().toString(36).substr(2, 9),
        name,
        amount: parseFloat(amount),
        daysOfMonth: selectedDays,
        category,
        paymentMethod: 'Dinheiro / Pix',
        active: true,
        processedDays: {}
      };
      onAddRule(newRule);
    }

    resetForm();
  };

  const days1to31 = Array.from({ length: 31 }, (_, i) => i + 1);

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[130] flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-t-[32px] sm:rounded-3xl w-full max-w-md max-h-[85vh] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex justify-between items-center bg-slate-900/80">
          <div>
            <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <span className="text-emerald-400">⚡</span> Saldo Automático em Caixa
            </h3>
            <p className="text-xs text-slate-400">Credita receitas no caixa exatamente nos dias configurados</p>
          </div>
          <button onClick={onClose} className="p-2 bg-slate-800 text-slate-400 rounded-full hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {rules.length === 0 && !showAddForm && (
            <div className="text-center py-8 text-slate-500 text-sm">
              <Calendar size={36} className="mx-auto mb-2 opacity-30 text-emerald-400" />
              <p>Nenhuma regra de saldo automático cadastrada.</p>
              <p className="text-xs mt-1 text-slate-400">Cadastre dias como 10 e 20 para creditar seu salário sem digitar!</p>
            </div>
          )}

          {/* List of Rules */}
          {rules.map(rule => (
            <div key={rule.id} className={`p-4 rounded-2xl border transition-all ${rule.active ? 'bg-slate-800/60 border-slate-700' : 'bg-slate-900/40 border-slate-800 opacity-60'}`}>
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-bold text-slate-100 text-sm">{rule.name}</h4>
                  <div className="text-lg font-bold text-emerald-400 mt-0.5">
                    R$ {rule.amount.toFixed(2)}
                  </div>
                  <div className="text-xs text-slate-400 mt-1 flex items-center gap-1.5 flex-wrap">
                    <span className="bg-slate-700/60 px-2 py-0.5 rounded-md text-slate-300 font-medium">
                      Dias do mês: {rule.daysOfMonth.join(', ')}
                    </span>
                    <span className="text-slate-500">• {rule.category}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => startEditRule(rule)}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl"
                    title="Editar Regra"
                  >
                    <Edit2 size={15} />
                  </button>
                  <button
                    onClick={() => onToggleRule(rule.id)}
                    className={`p-2 rounded-xl border transition-colors ${rule.active ? 'bg-emerald-950/40 text-emerald-400 border-emerald-800/40' : 'bg-slate-800 text-slate-500 border-slate-700'}`}
                    title={rule.active ? 'Ativo' : 'Pausado'}
                  >
                    <Power size={15} />
                  </button>
                  <button
                    onClick={() => onDeleteRule(rule.id)}
                    className="p-2 bg-slate-800/80 text-red-400 rounded-xl hover:bg-red-950/30 transition-colors"
                    title="Excluir"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            </div>
          ))}

          {/* Form to Add / Edit Rule */}
          {showAddForm ? (
            <form onSubmit={handleSubmit} className="bg-slate-800/80 border border-slate-700 p-4 rounded-2xl space-y-4">
              <h4 className="font-bold text-sm text-slate-200">
                {editingRuleId ? 'Editar Regra de Recebimento' : 'Nova Regra de Recebimento'}
              </h4>

              <div>
                <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Descrição</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Salário / Adiantamento"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 p-2.5 rounded-xl text-sm font-semibold text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Valor Creditado por Data (R$)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  placeholder="Ex: 2200.00"
                  value={amount}
                  onChange={e => setAmount(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 p-2.5 rounded-xl text-lg font-bold text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Dias do Mês ({selectedDays.length} selecionado{selectedDays.length > 1 ? 's' : ''})
                </label>
                <p className="text-[11px] text-slate-400 mb-2">Toque nos dias em que o saldo deve entrar automaticamente:</p>
                <div className="grid grid-cols-7 gap-1.5 max-h-36 overflow-y-auto p-1 bg-slate-950 rounded-xl border border-slate-800">
                  {days1to31.map(day => {
                    const isSelected = selectedDays.includes(day);
                    return (
                      <button
                        key={day}
                        type="button"
                        onClick={() => toggleDay(day)}
                        className={`py-1.5 text-xs font-bold rounded-lg transition-all ${
                          isSelected
                            ? 'bg-emerald-600 text-white shadow'
                            : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                        }`}
                      >
                        {day}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 py-2.5 bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-lg active:scale-95"
                >
                  {editingRuleId ? 'Salvar Alterações' : 'Salvar Regra'}
                </button>
              </div>
            </form>
          ) : (
            <button
              onClick={() => {
                resetForm();
                setShowAddForm(true);
              }}
              className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold text-sm flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95"
            >
              <Plus size={18} /> Adicionar Regra de Saldo Automático
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
