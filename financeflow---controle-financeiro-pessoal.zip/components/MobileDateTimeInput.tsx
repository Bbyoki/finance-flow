import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Keyboard, Check } from 'lucide-react';

interface MobileDateTimeInputProps {
  value: string; // ISO format: YYYY-MM-DDTHH:mm
  onChange: (value: string) => void;
  required?: boolean;
}

export const MobileDateTimeInput: React.FC<MobileDateTimeInputProps> = ({ value, onChange, required }) => {
  const [mode, setMode] = useState<'NATIVE' | 'KEYBOARD'>('KEYBOARD');
  
  // Extract initial date and time
  const [datePart, setDatePart] = useState('');
  const [timePart, setTimePart] = useState('');

  useEffect(() => {
    if (value) {
      const [d, t] = value.split('T');
      if (d) setDatePart(d);
      if (t) setTimePart(t.slice(0, 5));
    } else {
      const now = new Date();
      now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
      const iso = now.toISOString();
      setDatePart(iso.slice(0, 10));
      setTimePart(iso.slice(11, 16));
      onChange(iso.slice(0, 16));
    }
  }, [value]);

  const updateCombined = (newDate: string, newTime: string) => {
    setDatePart(newDate);
    setTimePart(newTime);
    if (newDate && newTime) {
      onChange(`${newDate}T${newTime}`);
    } else if (newDate) {
      onChange(`${newDate}T12:00`);
    }
  };

  const setNow = () => {
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    const iso = now.toISOString();
    const d = iso.slice(0, 10);
    const t = iso.slice(11, 16);
    setDatePart(d);
    setTimePart(t);
    onChange(`${d}T${t}`);
  };

  const setYesterday = () => {
    const yesterday = new Date(Date.now() - 86400000);
    yesterday.setMinutes(yesterday.getMinutes() - yesterday.getTimezoneOffset());
    const iso = yesterday.toISOString();
    const d = iso.slice(0, 10);
    const t = timePart || iso.slice(11, 16);
    setDatePart(d);
    onChange(`${d}T${t}`);
  };

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
          <Calendar size={14} className="text-indigo-400" /> Data e Hora
        </label>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={setNow}
            className="text-[11px] font-semibold bg-indigo-950/60 hover:bg-indigo-900/80 text-indigo-300 px-2.5 py-1 rounded-lg border border-indigo-800/40 transition-colors flex items-center gap-1 active:scale-95"
          >
            <Clock size={12} /> Agora
          </button>
          <button
            type="button"
            onClick={setYesterday}
            className="text-[11px] font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded-lg border border-slate-700 transition-colors active:scale-95"
          >
            Ontem
          </button>
          <button
            type="button"
            onClick={() => setMode(m => m === 'KEYBOARD' ? 'NATIVE' : 'KEYBOARD')}
            className={`text-[11px] font-semibold px-2.5 py-1 rounded-lg border transition-colors flex items-center gap-1 active:scale-95 ${
              mode === 'KEYBOARD' 
                ? 'bg-indigo-600 text-white border-indigo-500' 
                : 'bg-slate-800 text-slate-300 border-slate-700'
            }`}
            title="Alternar modo de teclado"
          >
            <Keyboard size={12} /> {mode === 'KEYBOARD' ? 'Teclado' : 'Calendário'}
          </button>
        </div>
      </div>

      {mode === 'KEYBOARD' ? (
        <div className="grid grid-cols-2 gap-2">
          {/* Data input with numeric keyboard on mobile */}
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">Data (Ano-Mês-Dia)</span>
            <input
              type="date"
              required={required}
              value={datePart}
              onChange={(e) => updateCombined(e.target.value, timePart || '12:00')}
              className="w-full bg-slate-900 border border-slate-700 p-3 rounded-xl font-bold text-slate-100 text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none"
            />
          </div>
          {/* Time input with numeric keyboard */}
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">Hora (Horas : Minutos)</span>
            <input
              type="time"
              required={required}
              value={timePart}
              onChange={(e) => updateCombined(datePart || new Date().toISOString().slice(0, 10), e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 p-3 rounded-xl font-bold text-slate-100 text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none"
            />
          </div>
        </div>
      ) : (
        <div>
          <input
            type="datetime-local"
            required={required}
            value={value}
            onChange={(e) => {
              onChange(e.target.value);
              const [d, t] = e.target.value.split('T');
              if (d) setDatePart(d);
              if (t) setTimePart(t);
            }}
            className="w-full bg-slate-900 border border-slate-700 p-3 rounded-xl font-bold text-slate-100 text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none"
          />
        </div>
      )}
    </div>
  );
};
