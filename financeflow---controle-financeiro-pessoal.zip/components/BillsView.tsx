import React, { useState, useEffect } from 'react';
import { 
  MonthlyBill, 
  PaidBillArchive, 
  DeletedBillArchive, 
  RetentionSettings, 
  RetentionOption 
} from '../types';
import { 
  CheckCircle2, 
  Trash2, 
  RotateCcw, 
  Edit2, 
  AlertCircle, 
  Calendar, 
  Settings, 
  History, 
  XCircle,
  Plus,
  ChevronDown,
  ChevronUp,
  Repeat
} from 'lucide-react';

interface BillsViewProps {
  bills: MonthlyBill[];
  paidHistory: PaidBillArchive[];
  deletedHistory: DeletedBillArchive[];
  retentionSettings: RetentionSettings;
  onToggleDueDate: (billId: string, dueDate: string) => void;
  onArchiveBill: (billId: string) => void;
  onRestorePaid: (archiveId: string) => void;
  onDeletePaid: (archiveId: string) => void;
  onClearPaidHistory: () => void;
  onRestoreDeleted: (deletedId: string) => void;
  onDeleteDeletedPermanently: (deletedId: string) => void;
  onClearDeletedHistory: () => void;
  onUpdateRetention: (settings: RetentionSettings) => void;
  onStartEdit: (bill: MonthlyBill) => void;
  onStartDelete: (bill: MonthlyBill) => void;
  onOpenAddModal: () => void;
}

export const BillsView: React.FC<BillsViewProps> = ({
  bills,
  paidHistory,
  deletedHistory,
  retentionSettings,
  onToggleDueDate,
  onArchiveBill,
  onRestorePaid,
  onDeletePaid,
  onClearPaidHistory,
  onRestoreDeleted,
  onDeleteDeletedPermanently,
  onClearDeletedHistory,
  onUpdateRetention,
  onStartEdit,
  onStartDelete,
  onOpenAddModal
}) => {
  const [activeTab, setActiveTab] = useState<'ACTIVE' | 'PAID_HISTORY' | 'DELETED_TRASH'>('ACTIVE');
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  
  // Accordion expansion state per bill
  const [expandedBillIds, setExpandedBillIds] = useState<{ [billId: string]: boolean }>({});

  const toggleExpand = (id: string) => {
    setExpandedBillIds(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  // 3-second countdown tracker for newly paid bills
  const [archivingBillIds, setArchivingBillIds] = useState<{ [billId: string]: number }>({});

  // Handle countdown timers
  useEffect(() => {
    const timers: NodeJS.Timeout[] = [];

    Object.keys(archivingBillIds).forEach(billId => {
      const remainingSeconds = archivingBillIds[billId];
      if (remainingSeconds > 0) {
        const timer = setTimeout(() => {
          setArchivingBillIds(prev => ({
            ...prev,
            [billId]: prev[billId] - 1
          }));
        }, 1000);
        timers.push(timer);
      } else if (remainingSeconds === 0) {
        // Move to paid history!
        onArchiveBill(billId);
        setArchivingBillIds(prev => {
          const next = { ...prev };
          delete next[billId];
          return next;
        });
      }
    });

    return () => timers.forEach(t => clearTimeout(t));
  }, [archivingBillIds, onArchiveBill]);

  const handleMarkDueDate = (bill: MonthlyBill, dateStr: string) => {
    // If bill will be completely paid by this action
    const isCurrentlyPaid = bill.paidDueDates.includes(dateStr);
    const updatedPaidList = isCurrentlyPaid 
      ? bill.paidDueDates.filter(d => d !== dateStr) 
      : [...bill.paidDueDates, dateStr];

    const willBeAllPaid = bill.dueDates.length > 0 && bill.dueDates.every(d => updatedPaidList.includes(d));

    onToggleDueDate(bill.id, dateStr);

    if (willBeAllPaid && !isCurrentlyPaid) {
      // Start 3-second timer
      setArchivingBillIds(prev => ({
        ...prev,
        [bill.id]: 3
      }));
    } else {
      // If was canceling, remove from countdown
      setArchivingBillIds(prev => {
        const next = { ...prev };
        delete next[bill.id];
        return next;
      });
    }
  };

  const cancelArchiving = (bill: MonthlyBill) => {
    setArchivingBillIds(prev => {
      const next = { ...prev };
      delete next[bill.id];
      return next;
    });
    // Unmark the last due date
    if (bill.dueDates.length > 0) {
      onToggleDueDate(bill.id, bill.dueDates[bill.dueDates.length - 1]);
    }
  };

  const formatDate = (d: string) => {
    if (!d) return '';
    try {
      const parts = d.split('-');
      if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
      return new Date(d).toLocaleDateString('pt-BR');
    } catch (e) {
      return d;
    }
  };

  const totalActive = bills.reduce((acc, b) => acc + b.amount, 0);

  return (
    <div className="space-y-4">
      {/* Subheader and Tabs */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-100">Contas do Mês</h2>
          <p className="text-xs text-slate-400">Total a pagar: R$ {totalActive.toFixed(2)}</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowSettingsModal(true)}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 transition-colors"
            title="Configurações de retenção do histórico"
          >
            <Settings size={18} />
          </button>
          <button
            onClick={onOpenAddModal}
            className="px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md active:scale-95"
          >
            <Plus size={16} /> Nova Conta
          </button>
        </div>
      </div>

      {/* Navigation Pills */}
      <div className="grid grid-cols-3 gap-1 bg-slate-900 p-1 rounded-2xl border border-slate-800 text-xs font-bold">
        <button
          onClick={() => setActiveTab('ACTIVE')}
          className={`py-2 rounded-xl transition-all ${activeTab === 'ACTIVE' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'}`}
        >
          A Pagar ({bills.length})
        </button>
        <button
          onClick={() => setActiveTab('PAID_HISTORY')}
          className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1 ${activeTab === 'PAID_HISTORY' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'}`}
        >
          <History size={13} /> Pagas ({paidHistory.length})
        </button>
        <button
          onClick={() => setActiveTab('DELETED_TRASH')}
          className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1 ${activeTab === 'DELETED_TRASH' ? 'bg-red-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'}`}
        >
          <Trash2 size={13} /> Lixeira ({deletedHistory.length})
        </button>
      </div>

      {/* TAB 1: ACTIVE BILLS */}
      {activeTab === 'ACTIVE' && (
        <div className="space-y-3">
          {bills.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-sm">
              <Calendar size={36} className="mx-auto mb-2 opacity-20" />
              <p>Nenhuma conta pendente.</p>
              <p className="text-xs text-slate-600 mt-1">Toque no botão "+ Nova Conta" para agendar.</p>
            </div>
          ) : (
            bills.map(bill => {
              const countdown = archivingBillIds[bill.id];
              const isArchiving = countdown !== undefined && countdown >= 0;
              const isExpanded = !!expandedBillIds[bill.id];
              const paidCount = bill.paidDueDates.length;
              const totalCount = bill.dueDates.length;
              const allPaid = totalCount > 0 && paidCount === totalCount;

              // Find next upcoming due date
              const nextUnpaidDate = bill.dueDates.find(d => !bill.paidDueDates.includes(d));

              return (
                <div 
                  key={bill.id} 
                  className={`rounded-2xl border transition-all overflow-hidden ${
                    isArchiving 
                      ? 'bg-emerald-950/40 border-emerald-500/50 shadow-lg ring-1 ring-emerald-500/40 animate-pulse' 
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {/* Collapsed Preview Card Header (Tapping toggles accordion) */}
                  <div 
                    onClick={() => toggleExpand(bill.id)}
                    className="p-4 cursor-pointer flex items-center justify-between select-none"
                  >
                    <div className="flex-1 mr-3 overflow-hidden">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-slate-100 text-base truncate">{bill.name}</h4>
                        {bill.category && (
                          <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full font-medium shrink-0">
                            {bill.category}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
                        {bill.isSubscription ? (
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-950 text-indigo-300 border border-indigo-800/40 flex items-center gap-1">
                            <Repeat size={10} /> Assinatura Mensal (Dia {bill.subscriptionDay || (bill.dueDates[0] ? bill.dueDates[0].split('-')[2] : '')})
                          </span>
                        ) : (
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                            allPaid 
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/40' 
                              : 'bg-slate-800 text-slate-300'
                          }`}>
                            {paidCount}/{totalCount} vencimento{totalCount > 1 ? 's' : ''} pago{paidCount > 1 ? 's' : ''}
                          </span>
                        )}

                        {nextUnpaidDate && !allPaid && (
                          <span className="text-[11px] text-amber-400 flex items-center gap-1 font-semibold truncate">
                            <Calendar size={11} /> Próx: {formatDate(nextUnpaidDate)}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="font-extrabold text-slate-100 text-base">
                        R$ {bill.amount.toFixed(2)}
                      </span>
                      <div className={`p-1.5 rounded-lg bg-slate-800 text-slate-400 transition-transform duration-200 ${isExpanded ? 'rotate-180 bg-indigo-950/50 text-indigo-400' : ''}`}>
                        <ChevronDown size={16} />
                      </div>
                    </div>
                  </div>

                  {/* Expanded Section (Reveals due dates and individual installment buttons) */}
                  {isExpanded && (
                    <div className="px-4 pb-4 pt-1 border-t border-slate-800/70 space-y-3 animate-in fade-in duration-200">
                      
                      {/* Vencimentos List */}
                      <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 space-y-2">
                        {bill.isSubscription ? (
                          <div className="text-[11px] text-indigo-300 bg-indigo-950/40 p-2.5 rounded-lg border border-indigo-900/40 flex items-start gap-2">
                            <Repeat size={14} className="text-indigo-400 shrink-0 mt-0.5" />
                            <span>
                              <strong>Assinatura Mensal Contínua:</strong> Vence todo dia {bill.subscriptionDay || (bill.dueDates[0] ? bill.dueDates[0].split('-')[2] : '')}. Ao marcar como pago, este pagamento é registrado no histórico vitalício e a conta avança para o próximo mês no fim da fila.
                            </span>
                          </div>
                        ) : (
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                            Toque no vencimento para marcar como pago:
                          </span>
                        )}

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {bill.dueDates.map((dateStr, idx) => {
                            const isDatePaid = bill.paidDueDates.includes(dateStr);
                            return (
                              <button
                                key={idx}
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleMarkDueDate(bill, dateStr);
                                }}
                                className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-between transition-all active:scale-95 ${
                                  isDatePaid 
                                    ? 'bg-emerald-600/90 hover:bg-emerald-500 text-white shadow-sm border border-emerald-500' 
                                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                                }`}
                              >
                                <div className="flex items-center gap-1.5">
                                  <Calendar size={13} className={isDatePaid ? 'text-white' : 'text-slate-400'} />
                                  <span>{bill.isSubscription ? 'Vencimento Atual' : `${idx + 1}ª Parcela`}: {formatDate(dateStr)}</span>
                                </div>
                                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                                  isDatePaid ? 'bg-white/20 text-white' : 'bg-slate-700 text-slate-400'
                                }`}>
                                  {isDatePaid ? 'Pago ✅' : 'Pagar'}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Footer Actions: Marcar tudo pago, editar, excluir */}
                      <div className="flex justify-between items-center pt-1">
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              onStartEdit(bill);
                            }} 
                            className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium flex items-center gap-1"
                          >
                            <Edit2 size={12} /> Editar
                          </button>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              onStartDelete(bill);
                            }} 
                            className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-red-400 rounded-lg text-xs font-medium flex items-center gap-1"
                          >
                            <Trash2 size={12} /> Excluir
                          </button>
                        </div>

                        {isArchiving ? (
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                              <CheckCircle2 size={14} /> {bill.isSubscription ? 'Assinatura Paga!' : 'Conta Paga!'} ({countdown}s)
                            </span>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                cancelArchiving(bill);
                              }}
                              className="text-[11px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded-md border border-slate-700"
                            >
                              Desfazer
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              bill.dueDates.forEach(d => {
                                if (!bill.paidDueDates.includes(d)) {
                                  onToggleDueDate(bill.id, d);
                                }
                              });
                              setArchivingBillIds(prev => ({ ...prev, [bill.id]: 3 }));
                            }}
                            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-md active:scale-95"
                          >
                            {bill.isSubscription ? 'Pagar Este Mês' : 'Quitar Conta'}
                          </button>
                        )}
                      </div>

                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* TAB 2: PAID BILLS HISTORY (Vitalício) */}
      {activeTab === 'PAID_HISTORY' && (
        <div className="space-y-3">
          <div className="flex justify-between items-center text-xs text-slate-400 px-1">
            <span>Histórico vitalício de contas quitadas</span>
            {paidHistory.length > 0 && (
              <button
                onClick={onClearPaidHistory}
                className="text-red-400 hover:text-red-300 font-semibold"
              >
                Limpar Histórico
              </button>
            )}
          </div>

          {paidHistory.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-sm">
              <CheckCircle2 size={36} className="mx-auto mb-2 opacity-20 text-emerald-400" />
              <p>Nenhuma conta no histórico ainda.</p>
              <p className="text-xs text-slate-600 mt-1">Ao marcar uma conta como paga, ela cairá aqui automaticamente.</p>
            </div>
          ) : (
            paidHistory.map(item => (
              <div key={item.id} className="bg-slate-900 p-4 rounded-2xl border border-slate-800 flex justify-between items-center">
                <div>
                  <div className="font-bold text-slate-100 text-sm flex items-center gap-1.5">
                    <CheckCircle2 size={14} className="text-emerald-400" />
                    {item.name}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Pago em: {new Date(item.paidAt).toLocaleDateString('pt-BR')} • {new Date(item.paidAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                  <div className="text-[10px] text-slate-500">
                    Vencimentos: {item.dueDates.map(d => formatDate(d)).join(', ')}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="font-bold text-slate-200 text-sm">R$ {item.amount.toFixed(2)}</span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onRestorePaid(item.id)}
                      className="p-1.5 bg-slate-800 text-indigo-400 hover:text-indigo-300 rounded-lg"
                      title="Restaurar conta para ativas"
                    >
                      <RotateCcw size={14} />
                    </button>
                    <button
                      onClick={() => onDeletePaid(item.id)}
                      className="p-1.5 bg-slate-800 text-red-400 hover:text-red-300 rounded-lg"
                      title="Excluir do histórico"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB 3: DELETED BILLS TRASH (Vitalício) */}
      {activeTab === 'DELETED_TRASH' && (
        <div className="space-y-3">
          <div className="flex justify-between items-center text-xs text-slate-400 px-1">
            <span>Histórico de contas excluídas (não apaga sozinho)</span>
            {deletedHistory.length > 0 && (
              <button
                onClick={onClearDeletedHistory}
                className="text-red-400 hover:text-red-300 font-semibold"
              >
                Esvaziar Lixeira
              </button>
            )}
          </div>

          {deletedHistory.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-sm">
              <Trash2 size={36} className="mx-auto mb-2 opacity-20" />
              <p>Lixeira vazia.</p>
            </div>
          ) : (
            deletedHistory.map(item => (
              <div key={item.id} className="bg-slate-900 p-4 rounded-2xl border border-slate-800 flex justify-between items-center">
                <div>
                  <div className="font-bold text-slate-100 text-sm">{item.name}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Excluída em: {new Date(item.deletedAt).toLocaleDateString('pt-BR')} • {new Date(item.deletedAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="font-bold text-slate-400 text-sm">R$ {item.amount.toFixed(2)}</span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onRestoreDeleted(item.id)}
                      className="p-1.5 bg-slate-800 text-emerald-400 hover:text-emerald-300 rounded-lg flex items-center gap-1 text-xs font-bold px-2"
                      title="Restaurar conta"
                    >
                      <RotateCcw size={13} /> Restaurar
                    </button>
                    <button
                      onClick={() => onDeleteDeletedPermanently(item.id)}
                      className="p-1.5 bg-slate-800 text-red-500 hover:text-red-400 rounded-lg"
                      title="Excluir permanentemente"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* RETENTION SETTINGS MODAL */}
      {showSettingsModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[140] flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-sm space-y-5">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-slate-100 text-lg flex items-center gap-2">
                <Settings size={18} className="text-indigo-400" /> Prazos de Histórico
              </h3>
              <button onClick={() => setShowSettingsModal(false)} className="text-slate-400 hover:text-white">
                <XCircle size={20} />
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Por padrão, os históricos são <strong>vitalícios</strong> e nunca se apagam sozinhos. Você pode alterar se desejar:
            </p>

            <div>
              <label className="text-xs font-bold text-slate-400 block mb-1 uppercase tracking-wider">
                Histórico de Contas Pagas
              </label>
              <select
                value={retentionSettings.paidBillsRetention}
                onChange={e => onUpdateRetention({
                  ...retentionSettings,
                  paidBillsRetention: e.target.value as RetentionOption
                })}
                className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-bold text-slate-100 text-sm focus:outline-none"
              >
                <option value="NEVER">Nunca apagar (Vitalício - Padrão)</option>
                <option value="30_DAYS">Apagar após 30 dias</option>
                <option value="60_DAYS">Apagar após 60 dias</option>
                <option value="90_DAYS">Apagar após 90 dias</option>
                <option value="180_DAYS">Apagar após 6 meses</option>
                <option value="365_DAYS">Apagar após 1 ano</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-400 block mb-1 uppercase tracking-wider">
                Histórico de Contas Excluídas (Lixeira)
              </label>
              <select
                value={retentionSettings.deletedBillsRetention}
                onChange={e => onUpdateRetention({
                  ...retentionSettings,
                  deletedBillsRetention: e.target.value as RetentionOption
                })}
                className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-bold text-slate-100 text-sm focus:outline-none"
              >
                <option value="NEVER">Nunca apagar (Vitalício - Padrão)</option>
                <option value="30_DAYS">Apagar após 30 dias</option>
                <option value="60_DAYS">Apagar após 60 dias</option>
                <option value="90_DAYS">Apagar após 90 dias</option>
                <option value="180_DAYS">Apagar após 6 meses</option>
                <option value="365_DAYS">Apagar após 1 ano</option>
              </select>
            </div>

            <button
              onClick={() => setShowSettingsModal(false)}
              className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold text-sm"
            >
              Concluído
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
