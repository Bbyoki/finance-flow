import React, { useState } from 'react';
import { 
  Target, 
  Plus, 
  Trash2, 
  Edit2, 
  CheckCircle2, 
  Calendar, 
  TrendingUp, 
  MinusCircle, 
  X,
  History,
  Star,
  Zap,
  Flame
} from 'lucide-react';
import { Goal, GoalHistoryEntry } from '../types';
import { GOAL_CATEGORIES } from '../constants';

interface GoalsViewProps {
  goals: Goal[];
  onOpenAddGoalModal: () => void;
  onStartEditGoal: (goal: Goal) => void;
  onStartDeleteGoal: (goal: Goal) => void;
  onToggleFocus: (goalId: string) => void;
  onContribute: (goalId: string, amount: number, type: 'DEPOSIT' | 'WITHDRAW', note: string, debitFromCash: boolean) => void;
}

export const GoalsView: React.FC<GoalsViewProps> = ({
  goals,
  onOpenAddGoalModal,
  onStartEditGoal,
  onStartDeleteGoal,
  onToggleFocus,
  onContribute
}) => {
  const [filter, setFilter] = useState<'FOCUS' | 'IN_PROGRESS' | 'ALL' | 'COMPLETED'>('IN_PROGRESS');
  const [activeGoalForContribute, setActiveGoalForContribute] = useState<{ goal: Goal; type: 'DEPOSIT' | 'WITHDRAW' } | null>(null);
  const [amountInput, setAmountInput] = useState<string>('');
  const [noteInput, setNoteInput] = useState<string>('');
  const [debitFromCash, setDebitFromCash] = useState<boolean>(true);
  const [viewingHistoryGoal, setViewingHistoryGoal] = useState<Goal | null>(null);

  const focusCount = goals.filter(g => g.isFocus).length;
  const inProgressCount = goals.filter(g => g.status !== 'COMPLETED').length;
  const completedCount = goals.filter(g => g.status === 'COMPLETED').length;

  const filteredGoals = goals.filter(g => {
    if (filter === 'FOCUS') return !!g.isFocus;
    if (filter === 'IN_PROGRESS') return g.status !== 'COMPLETED';
    if (filter === 'COMPLETED') return g.status === 'COMPLETED';
    return true;
  });

  const totalTarget = goals.reduce((acc, g) => acc + g.targetAmount, 0);
  const totalSaved = goals.reduce((acc, g) => acc + g.currentAmount, 0);
  const totalPercentage = totalTarget > 0 ? (totalSaved / totalTarget) * 100 : 0;

  const handleConfirmContribute = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeGoalForContribute) return;

    const parsed = parseFloat(amountInput);
    if (isNaN(parsed) || parsed <= 0) return;

    onContribute(
      activeGoalForContribute.goal.id,
      parsed,
      activeGoalForContribute.type,
      noteInput,
      debitFromCash
    );

    setActiveGoalForContribute(null);
    setAmountInput('');
    setNoteInput('');
  };

  return (
    <div className="space-y-4">
      {/* Header and Add Button */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Target size={22} className="text-indigo-400" /> Metas & Objetivos
          </h2>
          <p className="text-xs text-slate-400">
            Defina objetivos e selecione quais deseja focar
          </p>
        </div>
        <button
          onClick={onOpenAddGoalModal}
          className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md active:scale-95"
        >
          <Plus size={16} /> Nova Meta
        </button>
      </div>

      {/* Summary Box */}
      <div className="bg-gradient-to-br from-indigo-950/60 to-slate-900 p-4 rounded-2xl border border-indigo-900/40">
        <div className="flex justify-between items-baseline mb-2">
          <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider">
            Progresso Geral das Metas
          </span>
          <span className="text-sm font-bold text-slate-100">
            R$ {totalSaved.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} de R$ {totalTarget.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </span>
        </div>
        <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden mb-2">
          <div 
            className="h-full bg-gradient-to-r from-indigo-500 via-amber-400 to-emerald-400 rounded-full transition-all duration-500"
            style={{ width: `${Math.min(totalPercentage, 100)}%` }}
          />
        </div>
        <div className="flex justify-between text-[11px] text-slate-400 font-semibold">
          <span>{totalPercentage.toFixed(1)}% alcançado</span>
          <span>{inProgressCount} ativas • {completedCount} concluídas</span>
        </div>
      </div>

      {/* Filter Tabs - Differentiating Focus, In Progress, All, Completed */}
      <div className="grid grid-cols-4 gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-[11px] font-bold">
        <button
          onClick={() => setFilter('FOCUS')}
          className={`py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
            filter === 'FOCUS' ? 'bg-amber-500 text-slate-950 font-extrabold shadow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Star size={12} className={filter === 'FOCUS' ? 'fill-slate-950' : 'text-amber-400'} /> Foco ({focusCount})
        </button>
        <button
          onClick={() => setFilter('IN_PROGRESS')}
          className={`py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
            filter === 'IN_PROGRESS' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Zap size={12} /> Ativas ({inProgressCount})
        </button>
        <button
          onClick={() => setFilter('ALL')}
          className={`py-1.5 rounded-lg transition-all ${
            filter === 'ALL' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Todas ({goals.length})
        </button>
        <button
          onClick={() => setFilter('COMPLETED')}
          className={`py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
            filter === 'COMPLETED' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Feitas ({completedCount})
        </button>
      </div>

      {/* Goals List */}
      {filteredGoals.length === 0 ? (
        <div className="text-center py-14 text-slate-500 text-sm">
          <Target size={36} className="mx-auto mb-2 opacity-20" />
          <p>
            {filter === 'FOCUS' 
              ? 'Nenhuma meta marcada como foco. Toque na estrelinha ⭐ em qualquer meta para destacá-la!' 
              : filter === 'IN_PROGRESS'
              ? 'Nenhuma meta em andamento no momento.'
              : 'Nenhuma meta encontrada.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredGoals.map(goal => {
            const percentage = Math.min((goal.currentAmount / goal.targetAmount) * 100, 100);
            const remaining = Math.max(0, goal.targetAmount - goal.currentAmount);
            const isCompleted = goal.status === 'COMPLETED' || percentage >= 100;
            const categoryIcon = GOAL_CATEGORIES.find(c => c.id === goal.category)?.icon || <Target size={18} />;

            return (
              <div
                key={goal.id}
                className={`border rounded-3xl p-4 shadow-md space-y-3 transition-all relative overflow-hidden ${
                  goal.isFocus 
                    ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-amber-950/20 border-amber-500/60 ring-1 ring-amber-500/30' 
                    : isCompleted 
                    ? 'border-emerald-500/50 bg-slate-900/90' 
                    : 'bg-slate-900 border-slate-800'
                }`}
              >
                {/* Header row with Focus Star, Title and Category */}
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${
                      goal.isFocus 
                        ? 'bg-amber-950/50 text-amber-400 border border-amber-500/40' 
                        : isCompleted 
                        ? 'bg-emerald-950/50 text-emerald-400 border border-emerald-800/40' 
                        : 'bg-indigo-950/40 text-indigo-400 border border-indigo-800/40'
                    }`}>
                      {categoryIcon}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className="font-bold text-slate-100 text-sm sm:text-base">
                          {goal.title}
                        </h4>
                        {goal.isFocus && (
                          <span className="bg-amber-500/20 text-amber-400 text-[10px] px-2 py-0.5 rounded-full border border-amber-500/40 font-bold flex items-center gap-0.5">
                            <Star size={10} className="fill-amber-400" /> Foco
                          </span>
                        )}
                        {isCompleted && (
                          <span className="bg-emerald-950 text-emerald-400 text-[10px] px-2 py-0.5 rounded-full border border-emerald-800/50 font-bold">
                            Concluída 🎉
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {goal.category}
                        {goal.deadline && ` • Prazo: ${new Date(goal.deadline).toLocaleDateString('pt-BR')}`}
                      </div>
                    </div>
                  </div>

                  {/* Actions: Toggle Focus Star, History, Edit, Delete */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onToggleFocus(goal.id)}
                      className={`p-1.5 rounded-lg border transition-colors ${
                        goal.isFocus 
                          ? 'bg-amber-500/20 text-amber-400 border-amber-500/50' 
                          : 'bg-slate-800 text-slate-400 hover:text-amber-400 border-slate-700'
                      }`}
                      title={goal.isFocus ? 'Remover do foco' : 'Marcar como meta de foco prioritário'}
                    >
                      <Star size={14} className={goal.isFocus ? 'fill-amber-400' : ''} />
                    </button>
                    <button
                      onClick={() => setViewingHistoryGoal(goal)}
                      className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg border border-slate-700"
                      title="Histórico de aportes"
                    >
                      <History size={14} />
                    </button>
                    <button
                      onClick={() => onStartEditGoal(goal)}
                      className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg border border-slate-700"
                      title="Editar"
                    >
                      <Edit2 size={14} />
                    </button>
                    <button
                      onClick={() => onStartDeleteGoal(goal)}
                      className="p-1.5 bg-slate-800 hover:bg-slate-700 text-red-400 rounded-lg border border-slate-700"
                      title="Excluir"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                {goal.notes && (
                  <p className="text-xs text-slate-400 italic bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80">
                    "{goal.notes}"
                  </p>
                )}

                {/* Progress bar and numbers */}
                <div>
                  <div className="flex justify-between items-baseline mb-1 text-xs">
                    <span className="font-extrabold text-emerald-400 text-base">
                      R$ {goal.currentAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </span>
                    <span className="text-slate-400 font-medium">
                      Meta: R$ {goal.targetAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </span>
                  </div>

                  <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 rounded-full ${
                        goal.isFocus 
                          ? 'bg-gradient-to-r from-amber-500 to-amber-300' 
                          : isCompleted 
                          ? 'bg-emerald-400' 
                          : 'bg-indigo-500'
                      }`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>

                  <div className="flex justify-between text-[11px] text-slate-400 font-semibold mt-1">
                    <span>{percentage.toFixed(0)}% poupado</span>
                    <span className={remaining > 0 ? 'text-amber-400' : 'text-emerald-400'}>
                      {remaining > 0 ? `Faltam R$ ${remaining.toFixed(2)}` : 'Meta batida!'}
                    </span>
                  </div>
                </div>

                {/* Action Buttons: Aportar / Resgatar */}
                <div className="flex gap-2 pt-1 border-t border-slate-800">
                  <button
                    onClick={() => {
                      setActiveGoalForContribute({ goal, type: 'DEPOSIT' });
                      setAmountInput('');
                      setNoteInput('');
                      setDebitFromCash(true);
                    }}
                    className={`flex-1 py-2.5 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1 shadow-sm active:scale-95 transition-all ${
                      goal.isFocus ? 'bg-amber-600 hover:bg-amber-500 text-slate-950 font-extrabold' : 'bg-indigo-600 hover:bg-indigo-500'
                    }`}
                  >
                    <Plus size={14} /> Aportar
                  </button>
                  <button
                    onClick={() => {
                      setActiveGoalForContribute({ goal, type: 'WITHDRAW' });
                      setAmountInput('');
                      setNoteInput('');
                      setDebitFromCash(true);
                    }}
                    disabled={goal.currentAmount <= 0}
                    className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 rounded-xl text-xs font-bold flex items-center justify-center gap-1 active:scale-95"
                  >
                    <MinusCircle size={14} /> Resgatar
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* MODAL: CONTRIBUTE / WITHDRAW */}
      {activeGoalForContribute && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[140] flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-sm space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-slate-100 text-lg flex items-center gap-2">
                {activeGoalForContribute.type === 'DEPOSIT' ? (
                  <>
                    <Plus size={20} className="text-emerald-400" /> Aportar na Meta
                  </>
                ) : (
                  <>
                    <MinusCircle size={20} className="text-amber-400" /> Resgatar da Meta
                  </>
                )}
              </h3>
              <button onClick={() => setActiveGoalForContribute(null)} className="text-slate-400 hover:text-white">
                <X size={20} />
              </button>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block font-semibold uppercase">Meta</span>
              <div className="font-bold text-slate-100">{activeGoalForContribute.goal.title}</div>
              <div className="text-xs text-slate-400 mt-1">
                Saldo atual: R$ {activeGoalForContribute.goal.currentAmount.toFixed(2)} / Meta: R$ {activeGoalForContribute.goal.targetAmount.toFixed(2)}
              </div>
            </div>

            <form onSubmit={handleConfirmContribute} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Valor (R$)
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  placeholder="0,00"
                  value={amountInput}
                  onChange={e => setAmountInput(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-bold text-white text-xl focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Nota / Observação (Opcional)
                </label>
                <input
                  type="text"
                  placeholder="Ex: Economia do mês, bônus..."
                  value={noteInput}
                  onChange={e => setNoteInput(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <label className="flex items-start gap-2.5 cursor-pointer bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                <input
                  type="checkbox"
                  checked={debitFromCash}
                  onChange={e => setDebitFromCash(e.target.checked)}
                  className="mt-0.5 rounded text-indigo-600 focus:ring-0"
                />
                <span className="text-xs text-slate-300">
                  {activeGoalForContribute.type === 'DEPOSIT' 
                    ? 'Descontar do Saldo em Caixa (cria registro de saída)' 
                    : 'Devolver ao Saldo em Caixa (cria registro de entrada)'}
                </span>
              </label>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveGoalForContribute(null)}
                  className="flex-1 py-3 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className={`flex-1 py-3 text-white rounded-xl text-xs font-bold shadow-lg active:scale-95 ${
                    activeGoalForContribute.type === 'DEPOSIT' ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-amber-600 hover:bg-amber-500'
                  }`}
                >
                  {activeGoalForContribute.type === 'DEPOSIT' ? 'Confirmar Aporte' : 'Confirmar Resgate'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: VIEW GOAL HISTORY */}
      {viewingHistoryGoal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-[140] flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md max-h-[80vh] flex flex-col">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="font-bold text-slate-100 text-lg">Histórico de Aportes</h3>
                <p className="text-xs text-slate-400">{viewingHistoryGoal.title}</p>
              </div>
              <button onClick={() => setViewingHistoryGoal(null)} className="text-slate-400 hover:text-white">
                <X size={20} />
              </button>
            </div>

            <div className="overflow-y-auto space-y-2 flex-1 pr-1">
              {viewingHistoryGoal.history.length === 0 ? (
                <div className="text-center py-10 text-slate-500 text-sm">
                  Nenhum aporte registrado ainda.
                </div>
              ) : (
                viewingHistoryGoal.history.map(entry => (
                  <div key={entry.id} className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
                    <div>
                      <div className="font-semibold text-slate-200">{entry.note || (entry.type === 'DEPOSIT' ? 'Aporte' : 'Resgate')}</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        {new Date(entry.date).toLocaleDateString('pt-BR')} às {new Date(entry.date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                    <div className={`font-bold text-sm ${entry.type === 'DEPOSIT' ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {entry.type === 'DEPOSIT' ? '+' : '-'} R$ {entry.amount.toFixed(2)}
                    </div>
                  </div>
                ))
              )}
            </div>

            <button
              onClick={() => setViewingHistoryGoal(null)}
              className="w-full mt-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
            >
              Fechar
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
