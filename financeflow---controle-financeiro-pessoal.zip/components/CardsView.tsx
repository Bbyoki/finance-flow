import React, { useState } from 'react';
import { 
  CreditCard as CardIcon, 
  Plus, 
  Edit2, 
  Trash2, 
  History, 
  CheckCircle2, 
  X, 
  ChevronLeft,
  Calendar
} from 'lucide-react';
import { CreditCard, Transaction, PaidCardInvoice } from '../types';

interface CardsViewProps {
  cards: CreditCard[];
  transactions: Transaction[];
  paidCardInvoices: PaidCardInvoice[];
  onOpenAddModal: () => void;
  onStartEdit: (card: CreditCard) => void;
  onStartDelete: (card: CreditCard) => void;
  onPayInvoice: (cardId: string, amountPaid: number, totalInvoice: number, debitFromCash: boolean) => void;
  onUpdatePaidInvoice: (invoiceId: string, newAmount: number, newDate: string) => void;
  onDeletePaidInvoice: (invoiceId: string) => void;
}

export const CardsView: React.FC<CardsViewProps> = ({
  cards,
  transactions,
  paidCardInvoices,
  onOpenAddModal,
  onStartEdit,
  onStartDelete,
  onPayInvoice,
  onUpdatePaidInvoice,
  onDeletePaidInvoice
}) => {
  const [selectedCardForHistory, setSelectedCardForHistory] = useState<CreditCard | null>(null);
  const [payingCard, setPayingCard] = useState<CreditCard | null>(null);
  const [payAmount, setPayAmount] = useState<string>('');
  const [debitFromCash, setDebitFromCash] = useState<boolean>(true);

  // Edit paid invoice state
  const [editingInvoice, setEditingInvoice] = useState<PaidCardInvoice | null>(null);
  const [editInvoiceAmount, setEditInvoiceAmount] = useState<string>('');
  const [editInvoiceDate, setEditInvoiceDate] = useState<string>('');

  // Faithful calculation of card metrics
  const getCardMetrics = (cardId: string, limit: number) => {
    // Total expenses charged to this card
    const cardExpenses = transactions
      .filter(t => t.cardId === cardId && t.type === 'EXPENSE')
      .reduce((sum, t) => sum + t.amount, 0);

    // Total refunds/income credited to this card
    const cardRefunds = transactions
      .filter(t => t.cardId === cardId && t.type === 'INCOME')
      .reduce((sum, t) => sum + t.amount, 0);

    // Total invoices paid towards this card
    const cardPaidInvoices = paidCardInvoices
      .filter(p => p.cardId === cardId)
      .reduce((sum, p) => sum + p.amountPaid, 0);

    // Current unbilled / unpaid invoice debt
    const invoice = Math.max(0, cardExpenses - cardRefunds - cardPaidInvoices);
    const available = Math.max(0, limit - invoice);
    const progress = limit > 0 ? Math.min((invoice / limit) * 100, 100) : 0;

    return { invoice, available, progress };
  };

  const handleOpenPayModal = (card: CreditCard) => {
    const { invoice } = getCardMetrics(card.id, card.limit);
    setPayingCard(card);
    setPayAmount(invoice > 0 ? invoice.toFixed(2) : '0.00');
    setDebitFromCash(true);
  };

  const handleConfirmPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payingCard) return;

    const parsedAmount = parseFloat(payAmount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) return;

    const { invoice } = getCardMetrics(payingCard.id, payingCard.limit);
    onPayInvoice(payingCard.id, parsedAmount, invoice, debitFromCash);
    setPayingCard(null);
  };

  const handleOpenEditInvoice = (inv: PaidCardInvoice) => {
    setEditingInvoice(inv);
    setEditInvoiceAmount(inv.amountPaid.toString());
    setEditInvoiceDate(inv.paidAt.slice(0, 16));
  };

  const handleSaveEditInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingInvoice) return;

    const parsed = parseFloat(editInvoiceAmount);
    if (isNaN(parsed) || parsed <= 0) return;

    onUpdatePaidInvoice(editingInvoice.id, parsed, editInvoiceDate);
    setEditingInvoice(null);
  };

  const totalCardDebt = cards.reduce((acc, c) => acc + getCardMetrics(c.id, c.limit).invoice, 0);
  const totalCardLimit = cards.reduce((acc, c) => acc + c.limit, 0);

  return (
    <div className="space-y-5">
      {/* Header and Add button */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-100">Seus Cartões</h2>
          <p className="text-xs text-slate-400">
            Fatura Total: R$ {totalCardDebt.toFixed(2)} / Limite: R$ {totalCardLimit.toFixed(2)}
          </p>
        </div>
        <button
          onClick={onOpenAddModal}
          className="px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md active:scale-95"
        >
          <Plus size={16} /> Novo Cartão
        </button>
      </div>

      {cards.length === 0 ? (
        <div className="text-center py-16 text-slate-500 text-sm">
          <CardIcon size={40} className="mx-auto mb-2 opacity-20" />
          <p>Nenhum cartão cadastrado.</p>
          <p className="text-xs text-slate-600 mt-1">Cadastre seus cartões para controlar limite e faturas automaticamente.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {cards.map(card => {
            const { invoice, available, progress } = getCardMetrics(card.id, card.limit);

            return (
              <div 
                key={card.id} 
                className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg relative overflow-hidden space-y-4"
              >
                {/* Decorative glow */}
                <div className="absolute -right-8 -top-8 w-28 h-28 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />

                {/* Top Info */}
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-indigo-950/50 border border-indigo-800/40 flex items-center justify-center text-indigo-400">
                      <CardIcon size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-100 text-base">{card.bankName}</h4>
                      <p className="text-[11px] text-slate-400 uppercase font-semibold">
                        Vencimento todo dia {card.dueDay}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setSelectedCardForHistory(card)}
                      className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl"
                      title="Histórico de Faturas"
                    >
                      <History size={15} />
                    </button>
                    <button
                      onClick={() => onStartEdit(card)}
                      className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl"
                      title="Editar"
                    >
                      <Edit2 size={15} />
                    </button>
                    <button
                      onClick={() => onStartDelete(card)}
                      className="p-2 bg-slate-800 hover:bg-slate-700 text-red-400 rounded-xl"
                      title="Excluir"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>

                {/* Limit Visual Bar */}
                <div>
                  <div className="flex justify-between items-baseline mb-1.5 text-xs">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      Fatura Atual (Gasto)
                    </span>
                    <span className="font-bold text-slate-100 text-base">
                      R$ {invoice.toFixed(2)}
                    </span>
                  </div>
                  <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-500 rounded-full ${
                        progress > 85 ? 'bg-red-500' : progress > 60 ? 'bg-amber-500' : 'bg-indigo-500'
                      }`}
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] font-semibold text-slate-500 mt-1">
                    <span>{progress.toFixed(0)}% utilizado</span>
                    <span>Limite: R$ {card.limit.toFixed(2)}</span>
                  </div>
                </div>

                {/* Bottom Row with Available Limit & Action */}
                <div className="flex justify-between items-center pt-2 border-t border-slate-800">
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                      Limite Disponível
                    </span>
                    <span className="text-base font-bold text-emerald-400">
                      R$ {available.toFixed(2)}
                    </span>
                  </div>

                  <button
                    onClick={() => handleOpenPayModal(card)}
                    disabled={invoice <= 0}
                    className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95 ${
                      invoice > 0 
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white' 
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    <CheckCircle2 size={14} />
                    {invoice > 0 ? 'Pagar Fatura' : 'Fatura em Dia'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* MODAL: PAY INVOICE (FATURA PAGA) */}
      {payingCard && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-[140] flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-sm space-y-4 animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-slate-100 text-lg flex items-center gap-2">
                <CheckCircle2 size={20} className="text-emerald-400" />
                Pagar Fatura
              </h3>
              <button onClick={() => setPayingCard(null)} className="text-slate-400 hover:text-white">
                <X size={20} />
              </button>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <span className="text-xs text-slate-400 block font-medium">Cartão</span>
              <div className="text-base font-bold text-slate-100">{payingCard.bankName}</div>
              <div className="text-xs text-slate-400 mt-2">Fatura Atual a pagar:</div>
              <div className="text-2xl font-bold text-indigo-400">
                R$ {getCardMetrics(payingCard.id, payingCard.limit).invoice.toFixed(2)}
              </div>
            </div>

            <form onSubmit={handleConfirmPayment} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Valor a Pagar (R$)
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-3 text-slate-400 font-bold text-sm">R$</span>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={payAmount}
                    onChange={e => setPayAmount(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 pl-10 pr-3 py-2.5 rounded-xl font-bold text-white text-lg focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div className="flex gap-2 mt-2">
                  <button
                    type="button"
                    onClick={() => setPayAmount(getCardMetrics(payingCard.id, payingCard.limit).invoice.toFixed(2))}
                    className="text-[11px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded-lg border border-slate-700"
                  >
                    Valor Total
                  </button>
                </div>
              </div>

              {/* Checkbox to debit from cash balance */}
              <label className="flex items-start gap-2.5 cursor-pointer bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                <input
                  type="checkbox"
                  checked={debitFromCash}
                  onChange={e => setDebitFromCash(e.target.checked)}
                  className="mt-0.5 rounded text-indigo-600 focus:ring-0"
                />
                <span className="text-xs text-slate-300">
                  Descontar do <strong>Saldo em Caixa</strong> (cria registro de despesa do pagamento da fatura)
                </span>
              </label>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPayingCard(null)}
                  className="flex-1 py-3 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-lg active:scale-95 flex items-center justify-center gap-1.5"
                >
                  Confirmar Pagamento
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL / DRAWER: CARD INVOICE HISTORY */}
      {selectedCardForHistory && (
        <div className="fixed inset-0 bg-slate-950 z-[140] flex flex-col animate-in slide-in-from-right duration-200">
          <header className="p-4 bg-slate-900 border-b border-slate-800 flex items-center gap-3">
            <button
              onClick={() => setSelectedCardForHistory(null)}
              className="p-2 bg-slate-800 rounded-full text-slate-300 hover:text-white"
            >
              <ChevronLeft size={20} />
            </button>
            <div>
              <h2 className="text-lg font-bold text-slate-100">Faturas Pagas</h2>
              <p className="text-xs text-slate-400">{selectedCardForHistory.bankName}</p>
            </div>
          </header>

          <div className="p-4 space-y-3 flex-1 overflow-y-auto">
            {paidCardInvoices.filter(h => h.cardId === selectedCardForHistory.id).length === 0 ? (
              <div className="text-center py-16 text-slate-500 text-sm">
                <History size={36} className="mx-auto mb-2 opacity-20" />
                <p>Nenhuma fatura paga registrada para este cartão.</p>
                <p className="text-xs text-slate-600 mt-1">Ao quitar uma fatura com "Pagar Fatura", o histórico vitalício fica aqui.</p>
              </div>
            ) : (
              paidCardInvoices
                .filter(h => h.cardId === selectedCardForHistory.id)
                .sort((a, b) => new Date(b.paidAt).getTime() - new Date(a.paidAt).getTime())
                .map(item => (
                  <div key={item.id} className="bg-slate-900 p-4 rounded-2xl border border-slate-800 flex justify-between items-center">
                    <div>
                      <div className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                        <CheckCircle2 size={14} className="text-emerald-400" />
                        Fatura Paga
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {new Date(item.paidAt).toLocaleDateString('pt-BR')} às {new Date(item.paidAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                      </div>
                      <div className="text-[10px] text-slate-500">
                        Fatura total registrada: R$ {item.totalInvoiceAmount.toFixed(2)}
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <div className="text-base font-bold text-emerald-400">
                          R$ {item.amountPaid.toFixed(2)}
                        </div>
                        <span className="text-[10px] bg-emerald-950/40 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800/40 font-semibold">
                          Liquidada
                        </span>
                      </div>

                      {/* Edit / Delete actions on paid invoice */}
                      <div className="flex flex-col gap-1">
                        <button
                          onClick={() => handleOpenEditInvoice(item)}
                          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg"
                          title="Editar valor ou data desta fatura paga"
                        >
                          <Edit2 size={13} />
                        </button>
                        <button
                          onClick={() => onDeletePaidInvoice(item.id)}
                          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-red-400 rounded-lg"
                          title="Excluir fatura do histórico"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
            )}
          </div>
        </div>
      )}

      {/* MODAL: EDIT PAID INVOICE */}
      {editingInvoice && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-sm space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
                <Edit2 size={18} className="text-indigo-400" />
                Editar Fatura Paga
              </h3>
              <button onClick={() => setEditingInvoice(null)} className="text-slate-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Corrija o valor ou data do pagamento da fatura caso tenha se enganado.
            </p>

            <form onSubmit={handleSaveEditInvoice} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Valor Pago (R$)
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={editInvoiceAmount}
                  onChange={e => setEditInvoiceAmount(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl font-bold text-white text-base focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Data do Pagamento
                </label>
                <input
                  type="datetime-local"
                  required
                  value={editInvoiceDate}
                  onChange={e => setEditInvoiceDate(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl font-bold text-white text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingInvoice(null)}
                  className="flex-1 py-2.5 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold"
                >
                  Salvar Alterações
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
