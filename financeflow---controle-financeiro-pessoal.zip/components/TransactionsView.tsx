import React, { useState, useMemo } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  ArrowDownCircle, 
  ArrowUpCircle, 
  Calendar, 
  CreditCard as CardIcon, 
  Wallet, 
  SlidersHorizontal, 
  X, 
  Edit2, 
  Trash2,
  ChevronDown
} from 'lucide-react';
import { Transaction, CreditCard, TransactionType } from '../types';
import { CATEGORIES } from '../constants';

interface TransactionsViewProps {
  transactions: Transaction[];
  cards: CreditCard[];
  onOpenAddModal: () => void;
  onStartEdit: (tx: Transaction) => void;
  onStartDelete: (tx: Transaction) => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({
  transactions,
  cards,
  onOpenAddModal,
  onStartEdit,
  onStartDelete
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<'ALL' | 'EXPENSE' | 'INCOME'>('ALL');
  const [selectedPeriod, setSelectedPeriod] = useState<'CURRENT_MONTH' | 'LAST_7_DAYS' | 'PREVIOUS_MONTH' | 'CURRENT_YEAR' | 'ALL'>('CURRENT_MONTH');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [sortOrder, setSortOrder] = useState<'NEWEST' | 'OLDEST' | 'HIGHEST' | 'LOWEST'>('NEWEST');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  // Date boundary calculations
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();

  const filteredTransactions = useMemo(() => {
    return transactions.filter(tx => {
      // 1. Search text filter
      if (searchTerm.trim()) {
        const term = searchTerm.toLowerCase();
        const descMatch = (tx.description || '').toLowerCase().includes(term);
        const catMatch = (tx.category || '').toLowerCase().includes(term);
        const methodMatch = (tx.paymentMethod || '').toLowerCase().includes(term);
        if (!descMatch && !catMatch && !methodMatch) return false;
      }

      // 2. Type filter
      if (selectedType !== 'ALL' && tx.type !== selectedType) {
        return false;
      }

      // 3. Payment Method filter
      if (selectedPaymentMethod !== 'ALL') {
        if (selectedPaymentMethod === 'Crédito' && (!tx.paymentMethod?.includes('Crédito') && !tx.cardId)) {
          return false;
        } else if (selectedPaymentMethod !== 'Crédito' && tx.paymentMethod !== selectedPaymentMethod) {
          return false;
        }
      }

      // 4. Category filter
      if (selectedCategory !== 'ALL' && tx.category !== selectedCategory) {
        return false;
      }

      // 5. Period filter
      if (selectedPeriod !== 'ALL') {
        const txDate = new Date(tx.date);
        if (selectedPeriod === 'CURRENT_MONTH') {
          if (txDate.getFullYear() !== currentYear || txDate.getMonth() !== currentMonth) {
            return false;
          }
        } else if (selectedPeriod === 'LAST_7_DAYS') {
          const sevenDaysAgo = new Date(Date.now() - 7 * 86400000);
          if (txDate.getTime() < sevenDaysAgo.getTime()) {
            return false;
          }
        } else if (selectedPeriod === 'PREVIOUS_MONTH') {
          const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
          const prevYear = currentMonth === 0 ? currentYear - 1 : currentYear;
          if (txDate.getFullYear() !== prevYear || txDate.getMonth() !== prevMonth) {
            return false;
          }
        } else if (selectedPeriod === 'CURRENT_YEAR') {
          if (txDate.getFullYear() !== currentYear) {
            return false;
          }
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortOrder === 'NEWEST') {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      }
      if (sortOrder === 'OLDEST') {
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      }
      if (sortOrder === 'HIGHEST') {
        return b.amount - a.amount;
      }
      if (sortOrder === 'LOWEST') {
        return a.amount - b.amount;
      }
      return 0;
    });
  }, [transactions, searchTerm, selectedType, selectedPeriod, selectedPaymentMethod, selectedCategory, sortOrder]);

  // Subtotal calculations for filtered items
  const filteredIncome = useMemo(() => {
    return filteredTransactions
      .filter(t => t.type === 'INCOME')
      .reduce((acc, t) => acc + t.amount, 0);
  }, [filteredTransactions]);

  const filteredExpense = useMemo(() => {
    return filteredTransactions
      .filter(t => t.type === 'EXPENSE')
      .reduce((acc, t) => acc + t.amount, 0);
  }, [filteredTransactions]);

  const isAnyFilterActive = searchTerm !== '' || selectedType !== 'ALL' || selectedPeriod !== 'CURRENT_MONTH' || selectedPaymentMethod !== 'ALL' || selectedCategory !== 'ALL' || sortOrder !== 'NEWEST';

  const resetFilters = () => {
    setSearchTerm('');
    setSelectedType('ALL');
    setSelectedPeriod('CURRENT_MONTH');
    setSelectedPaymentMethod('ALL');
    setSelectedCategory('ALL');
    setSortOrder('NEWEST');
  };

  return (
    <div className="space-y-4">
      {/* Header and Add Button */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-100">Gastos & Receitas</h2>
          <p className="text-xs text-slate-400">
            {filteredTransactions.length} de {transactions.length} lançamentos
          </p>
        </div>
        <button
          onClick={onOpenAddModal}
          className="px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md active:scale-95"
        >
          <Plus size={16} /> Novo Gasto
        </button>
      </div>

      {/* Quick Search and Filter Toggle */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Pesquisar por nome, mercado, categoria..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 pl-10 pr-9 py-2.5 rounded-2xl text-xs font-semibold text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
            >
              <X size={16} />
            </button>
          )}
        </div>
        <button
          onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
          className={`p-2.5 rounded-2xl border flex items-center gap-1.5 text-xs font-bold transition-colors ${
            showAdvancedFilters || isAnyFilterActive
              ? 'bg-indigo-950/80 text-indigo-300 border-indigo-700/60'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
        >
          <SlidersHorizontal size={16} />
          <span className="hidden sm:inline">Filtros</span>
          {isAnyFilterActive && (
            <span className="w-2 h-2 rounded-full bg-indigo-400"></span>
          )}
        </button>
      </div>

      {/* Period Pills Bar (Quick period rule) */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs font-semibold">
        <button
          onClick={() => setSelectedPeriod('CURRENT_MONTH')}
          className={`px-3 py-1.5 rounded-xl shrink-0 transition-all ${
            selectedPeriod === 'CURRENT_MONTH'
              ? 'bg-indigo-600 text-white shadow'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          📅 Este Mês
        </button>
        <button
          onClick={() => setSelectedPeriod('LAST_7_DAYS')}
          className={`px-3 py-1.5 rounded-xl shrink-0 transition-all ${
            selectedPeriod === 'LAST_7_DAYS'
              ? 'bg-indigo-600 text-white shadow'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          Últimos 7 Dias
        </button>
        <button
          onClick={() => setSelectedPeriod('PREVIOUS_MONTH')}
          className={`px-3 py-1.5 rounded-xl shrink-0 transition-all ${
            selectedPeriod === 'PREVIOUS_MONTH'
              ? 'bg-indigo-600 text-white shadow'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          Mês Anterior
        </button>
        <button
          onClick={() => setSelectedPeriod('CURRENT_YEAR')}
          className={`px-3 py-1.5 rounded-xl shrink-0 transition-all ${
            selectedPeriod === 'CURRENT_YEAR'
              ? 'bg-indigo-600 text-white shadow'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          Ano {currentYear}
        </button>
        <button
          onClick={() => setSelectedPeriod('ALL')}
          className={`px-3 py-1.5 rounded-xl shrink-0 transition-all ${
            selectedPeriod === 'ALL'
              ? 'bg-indigo-600 text-white shadow'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          Todos os Tempos
        </button>
      </div>

      {/* Advanced Filter Panel */}
      {showAdvancedFilters && (
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3.5 animate-in slide-in-from-top-2 duration-200 text-xs">
          {/* Row 1: Tipo & Ordenação */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Tipo de Transação
              </label>
              <select
                value={selectedType}
                onChange={e => setSelectedType(e.target.value as any)}
                className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl font-semibold text-slate-200 focus:outline-none"
              >
                <option value="ALL">Todas (Entradas e Saídas)</option>
                <option value="EXPENSE">Apenas Despesas (Gastos)</option>
                <option value="INCOME">Apenas Receitas (Entradas)</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Ordenar Por
              </label>
              <select
                value={sortOrder}
                onChange={e => setSortOrder(e.target.value as any)}
                className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl font-semibold text-slate-200 focus:outline-none"
              >
                <option value="NEWEST">Mais Recentes Primeiro</option>
                <option value="OLDEST">Mais Antigos Primeiro</option>
                <option value="HIGHEST">Maior Valor</option>
                <option value="LOWEST">Menor Valor</option>
              </select>
            </div>
          </div>

          {/* Row 2: Método & Categoria */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Forma de Pagamento
              </label>
              <select
                value={selectedPaymentMethod}
                onChange={e => setSelectedPaymentMethod(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl font-semibold text-slate-200 focus:outline-none"
              >
                <option value="ALL">Todas as Formas</option>
                <option value="Dinheiro / Pix">Dinheiro / Pix</option>
                <option value="Cartão de Débito">Cartão de Débito</option>
                <option value="Crédito">Cartão de Crédito</option>
                <option value="Boleto">Boleto Bancário</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Categoria
              </label>
              <select
                value={selectedCategory}
                onChange={e => setSelectedCategory(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 p-2.5 rounded-xl font-semibold text-slate-200 focus:outline-none"
              >
                <option value="ALL">Todas as Categorias</option>
                {CATEGORIES.map(c => (
                  <option key={c.id} value={c.id}>{c.id}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Reset Filters button */}
          {isAnyFilterActive && (
            <div className="flex justify-end pt-1">
              <button
                onClick={resetFilters}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1"
              >
                <X size={13} /> Limpar Todos os Filtros
              </button>
            </div>
          )}
        </div>
      )}

      {/* Filter Summary Banner */}
      <div className="bg-slate-900/60 p-3 rounded-2xl border border-slate-800 flex justify-between items-center text-xs">
        <div className="flex items-center gap-3">
          <div>
            <span className="text-[10px] text-slate-500 font-semibold block uppercase">Gastos Filtrados</span>
            <span className="font-extrabold text-red-400">R$ {filteredExpense.toFixed(2)}</span>
          </div>
          <div className="w-px h-6 bg-slate-800" />
          <div>
            <span className="text-[10px] text-slate-500 font-semibold block uppercase">Entradas Filtradas</span>
            <span className="font-extrabold text-emerald-400">R$ {filteredIncome.toFixed(2)}</span>
          </div>
        </div>

        <span className="text-[11px] font-semibold text-slate-400">
          {filteredTransactions.length} item{filteredTransactions.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Transactions List */}
      <div className="space-y-2.5">
        {filteredTransactions.length === 0 ? (
          <div className="text-center py-16 text-slate-500 text-sm space-y-2">
            <Filter size={36} className="mx-auto opacity-20" />
            <p className="font-bold text-slate-300">Nenhum lançamento com os filtros selecionados.</p>
            <p className="text-xs text-slate-500">
              Tente mudar o período ou <button onClick={resetFilters} className="text-indigo-400 underline font-semibold">limpar os filtros</button>.
            </p>
          </div>
        ) : (
          filteredTransactions.map(tx => {
            const linkedCard = tx.cardId ? cards.find(c => c.id === tx.cardId) : null;

            return (
              <div
                key={tx.id}
                className="bg-slate-900 p-3.5 rounded-2xl border border-slate-800 flex items-center justify-between group hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center gap-3 overflow-hidden mr-2">
                  <div className={`w-9 h-9 shrink-0 rounded-xl flex items-center justify-center border ${
                    tx.type === 'INCOME' 
                      ? 'bg-emerald-950/40 text-emerald-400 border-emerald-800/40' 
                      : 'bg-red-950/40 text-red-400 border-red-800/40'
                  }`}>
                    {CATEGORIES.find(c => c.id === tx.category)?.icon || <Wallet size={16} />}
                  </div>
                  <div className="overflow-hidden">
                    <div className="text-sm font-bold text-slate-100 truncate">
                      {tx.description || tx.category}
                    </div>
                    <div className="text-[10px] text-slate-400 flex items-center gap-1 font-medium flex-wrap mt-0.5">
                      <span>{new Date(tx.date).toLocaleDateString('pt-BR')}</span>
                      <span>•</span>
                      <span>{tx.paymentMethod}</span>
                      {linkedCard && (
                        <span className="text-indigo-400 font-semibold">({linkedCard.bankName})</span>
                      )}
                      {tx.isAutoIncome && (
                        <span className="bg-emerald-950 text-emerald-300 px-1 rounded text-[9px] font-bold">Auto</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <div className={`text-sm font-bold text-right ${tx.type === 'INCOME' ? 'text-emerald-400' : 'text-slate-200'}`}>
                    {tx.type === 'INCOME' ? '+' : '-'} R$ {tx.amount.toFixed(2)}
                  </div>
                  <div className="flex items-center gap-1">
                    <button onClick={() => onStartEdit(tx)} className="p-1.5 text-slate-500 hover:text-indigo-400 rounded-lg bg-slate-800/60">
                      <Edit2 size={12} />
                    </button>
                    <button onClick={() => onStartDelete(tx)} className="p-1.5 text-slate-500 hover:text-red-400 rounded-lg bg-slate-800/60">
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
