import React, { useState } from 'react';
import { 
  TrendingUp, 
  Plus, 
  Folder, 
  FolderPlus, 
  Edit2, 
  Trash2, 
  Calendar, 
  DollarSign, 
  Filter,
  Layers,
  X
} from 'lucide-react';
import { Investment, InvestmentType } from '../types';
import { INVESTMENT_TYPES } from '../constants';

interface InvestmentsViewProps {
  investments: Investment[];
  folders: string[];
  onOpenAddModal: () => void;
  onStartEdit: (investment: Investment) => void;
  onStartDelete: (investment: Investment) => void;
  onAddFolder: (folderName: string) => void;
  onDeleteFolder: (folderName: string) => void;
}

export const InvestmentsView: React.FC<InvestmentsViewProps> = ({
  investments,
  folders,
  onOpenAddModal,
  onStartEdit,
  onStartDelete,
  onAddFolder,
  onDeleteFolder
}) => {
  const [selectedFolder, setSelectedFolder] = useState<string>('TODAS');
  const [showAddFolderModal, setShowAddFolderModal] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');

  const totalInvested = investments.reduce((acc, i) => acc + i.amount, 0);

  const filteredInvestments = selectedFolder === 'TODAS'
    ? investments
    : investments.filter(i => (i.folder || 'Geral') === selectedFolder);

  const handleCreateFolder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFolderName.trim()) return;
    onAddFolder(newFolderName.trim());
    setSelectedFolder(newFolderName.trim());
    setNewFolderName('');
    setShowAddFolderModal(false);
  };

  const getFolderTotal = (folderName: string) => {
    return investments
      .filter(i => (i.folder || 'Geral') === folderName)
      .reduce((acc, i) => acc + i.amount, 0);
  };

  return (
    <div className="space-y-4">
      {/* Header and Add Button */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <TrendingUp size={22} className="text-indigo-400" /> Investimentos
          </h2>
          <p className="text-xs text-slate-400">
            Total Patrimônio: R$ {totalInvested.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddFolderModal(true)}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700"
            title="Criar nova pasta / grupo"
          >
            <FolderPlus size={18} />
          </button>
          <button
            onClick={onOpenAddModal}
            className="px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md active:scale-95"
          >
            <Plus size={16} /> Novo Ativo
          </button>
        </div>
      </div>

      {/* Folders Bar */}
      <div className="space-y-1.5">
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
          Pastas e Grupos de Ativos
        </span>
        <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs font-semibold">
          <button
            onClick={() => setSelectedFolder('TODAS')}
            className={`px-3 py-2 rounded-xl shrink-0 transition-all flex items-center gap-1.5 ${
              selectedFolder === 'TODAS'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            <Layers size={14} /> Todas ({investments.length})
          </button>

          {folders.map(folder => {
            const count = investments.filter(i => (i.folder || 'Geral') === folder).length;
            const subtotal = getFolderTotal(folder);

            return (
              <button
                key={folder}
                onClick={() => setSelectedFolder(folder)}
                className={`px-3 py-2 rounded-xl shrink-0 transition-all flex items-center gap-1.5 ${
                  selectedFolder === folder
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                <Folder size={14} className={selectedFolder === folder ? 'text-white' : 'text-indigo-400'} />
                <span>{folder}</span>
                <span className="text-[10px] bg-black/30 px-1.5 py-0.5 rounded font-mono">
                  {count}
                </span>
              </button>
            );
          })}

          <button
            onClick={() => setShowAddFolderModal(true)}
            className="px-2.5 py-2 rounded-xl shrink-0 bg-slate-900 hover:bg-slate-800 text-indigo-400 border border-indigo-900/40 flex items-center gap-1 text-xs"
          >
            <Plus size={14} /> Nova Pasta
          </button>
        </div>
      </div>

      {/* Folder Subtotal Banner (when a specific folder is selected) */}
      {selectedFolder !== 'TODAS' && (
        <div className="bg-slate-900 p-3 rounded-2xl border border-slate-800 flex justify-between items-center text-xs">
          <div className="flex items-center gap-2">
            <Folder size={16} className="text-indigo-400" />
            <span className="font-bold text-slate-200">Pasta: {selectedFolder}</span>
          </div>
          <span className="font-bold text-emerald-400 text-sm">
            R$ {getFolderTotal(selectedFolder).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </span>
        </div>
      )}

      {/* Investments List */}
      {filteredInvestments.length === 0 ? (
        <div className="text-center py-16 text-slate-500 text-sm">
          <TrendingUp size={36} className="mx-auto mb-2 opacity-20" />
          <p>Nenhum investimento nesta pasta.</p>
          <p className="text-xs text-slate-600 mt-1">Cadastre criptomoedas, ações ou renda fixa organizados por pastas.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredInvestments.map(inv => {
            const typeConfig = INVESTMENT_TYPES.find(t => t.id === inv.type);

            return (
              <div
                key={inv.id}
                className="bg-slate-900 p-4 rounded-2xl border border-slate-800 flex items-center justify-between group hover:border-slate-700 transition-colors shadow-sm"
              >
                <div className="flex items-center gap-3 overflow-hidden mr-2">
                  <div className="w-10 h-10 shrink-0 rounded-2xl bg-slate-800 flex items-center justify-center border border-slate-700/80">
                    {typeConfig?.icon || <TrendingUp size={18} className="text-indigo-400" />}
                  </div>
                  <div className="overflow-hidden">
                    <div className="text-sm font-bold text-slate-100 truncate flex items-center gap-1.5">
                      {inv.name}
                    </div>
                    <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                      <span className="bg-slate-800 text-indigo-300 text-[10px] px-1.5 py-0.5 rounded font-medium border border-slate-700/60">
                        {inv.folder || 'Geral'}
                      </span>
                      <span>• {typeConfig?.label || 'Ativo'}</span>
                    </div>
                    {inv.notes && (
                      <div className="text-[10px] text-slate-500 truncate mt-0.5">
                        {inv.notes}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2.5 shrink-0">
                  <div className="text-right">
                    <div className="font-bold text-slate-100 text-sm sm:text-base">
                      R$ {inv.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </div>
                    <div className="text-[10px] text-slate-500">
                      {inv.date ? new Date(inv.date).toLocaleDateString('pt-BR') : ''}
                    </div>
                  </div>

                  <div className="flex flex-col gap-1">
                    <button
                      onClick={() => onStartEdit(inv)}
                      className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg"
                      title="Editar"
                    >
                      <Edit2 size={12} />
                    </button>
                    <button
                      onClick={() => onStartDelete(inv)}
                      className="p-1.5 bg-slate-800 hover:bg-slate-700 text-red-400 rounded-lg"
                      title="Excluir"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* MODAL: ADD FOLDER */}
      {showAddFolderModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[140] flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-sm space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-slate-100 text-lg flex items-center gap-2">
                <FolderPlus size={20} className="text-indigo-400" /> Nova Pasta de Investimento
              </h3>
              <button onClick={() => setShowAddFolderModal(false)} className="text-slate-400 hover:text-white">
                <X size={20} />
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Crie grupos organizados para separar suas criptos, ações de dividendos, reserva, etc.
            </p>

            <form onSubmit={handleCreateFolder} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Nome da Pasta
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Cripto DeFi, FIIs Tijolo, Reserva"
                  value={newFolderName}
                  onChange={e => setNewFolderName(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 p-3 rounded-xl font-bold text-white text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddFolderModal(false)}
                  className="flex-1 py-3 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg"
                >
                  Criar Pasta
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
