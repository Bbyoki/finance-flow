import React from 'react';
import { 
  Bell, 
  X, 
  AlertTriangle, 
  Clock, 
  Calendar, 
  CreditCard, 
  CheckCircle2, 
  ChevronRight,
  Trash2
} from 'lucide-react';
import { MonthlyBill, CreditCard as CardType, AppNotification } from '../types';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  bills: MonthlyBill[];
  cards: CreditCard[];
  dismissedIds?: string[];
  onDismissNotification: (id: string) => void;
  onClearAllNotifications: (ids: string[]) => void;
  onNavigateToBills: () => void;
  onNavigateToCards: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  bills,
  cards,
  dismissedIds = [],
  onDismissNotification,
  onClearAllNotifications,
  onNavigateToBills,
  onNavigateToCards
}) => {
  if (!isOpen) return null;

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const rawNotifications: AppNotification[] = [];

  // Check bills due dates
  bills.forEach(bill => {
    // For each unpaid due date
    bill.dueDates.forEach(dStr => {
      if (bill.paidDueDates.includes(dStr)) return;

      const notifId = `bill_${bill.id}_${dStr}`;

      const parts = dStr.split('-');
      if (parts.length === 3) {
        const d = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
        d.setHours(0, 0, 0, 0);

        const diffTime = d.getTime() - today.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays < 0) {
          // EXPIRED
          rawNotifications.push({
            id: notifId,
            title: `Conta Atrasada: ${bill.name}`,
            message: `Venceu há ${Math.abs(diffDays)} dia${Math.abs(diffDays) > 1 ? 's' : ''} (${parts[2]}/${parts[1]}). Regularize para evitar juros.`,
            type: 'EXPIRED',
            date: dStr,
            amount: bill.amount,
            billId: bill.id,
            dueDayOrDate: dStr,
            daysRemaining: diffDays
          });
        } else if (diffDays === 0) {
          // TODAY
          rawNotifications.push({
            id: notifId,
            title: `Vence Hoje: ${bill.name}`,
            message: `A conta de R$ ${bill.amount.toFixed(2)} vence hoje! Não se esqueça de pagar.`,
            type: 'TODAY',
            date: dStr,
            amount: bill.amount,
            billId: bill.id,
            dueDayOrDate: dStr,
            daysRemaining: 0
          });
        } else if (diffDays <= 5) {
          // SOON (next 5 days)
          rawNotifications.push({
            id: notifId,
            title: `Vence em ${diffDays} dia${diffDays > 1 ? 's' : ''}: ${bill.name}`,
            message: `Vencimento agendado para ${parts[2]}/${parts[1]}. Prepare seu saldo em caixa.`,
            type: 'SOON',
            date: dStr,
            amount: bill.amount,
            billId: bill.id,
            dueDayOrDate: dStr,
            daysRemaining: diffDays
          });
        }
      }
    });
  });

  // Check cards due days
  const currentDay = today.getDate();
  const cardMonthKey = `${today.getFullYear()}-${today.getMonth() + 1}`;
  cards.forEach(card => {
    let diffDays = card.dueDay - currentDay;
    if (diffDays < 0) {
      diffDays += 30;
    }

    if (diffDays <= 3) {
      rawNotifications.push({
        id: `card_${card.id}_${cardMonthKey}`,
        title: `Fatura ${card.bankName}`,
        message: diffDays === 0 
          ? `Vence hoje (dia ${card.dueDay})!` 
          : `Vence em ${diffDays} dia${diffDays > 1 ? 's' : ''} (dia ${card.dueDay}).`,
        type: 'CARD',
        date: today.toISOString(),
        amount: 0,
        cardId: card.id,
        dueDayOrDate: String(card.dueDay),
        daysRemaining: diffDays
      });
    }
  });

  // Filter out notifications that were dismissed by user!
  const notifications = rawNotifications
    .filter(n => !dismissedIds.includes(n.id))
    .sort((a, b) => a.daysRemaining - b.daysRemaining);

  const handleAction = (item: AppNotification) => {
    // Dismiss this notification so it disappears immediately!
    onDismissNotification(item.id);
    onClose();
    if (item.type === 'CARD') {
      onNavigateToCards();
    } else {
      onNavigateToBills();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[150] flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-t-[32px] sm:rounded-3xl w-full max-w-md max-h-[85vh] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex justify-between items-center bg-slate-900/90">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-950/70 border border-indigo-800/50 flex items-center justify-center text-indigo-400">
              <Bell size={18} />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                Avisos e Vencimentos
                {notifications.length > 0 && (
                  <span className="text-[10px] bg-red-600 text-white font-extrabold px-1.5 py-0.5 rounded-full">
                    {notifications.length}
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400">Contas e faturas próximas do vencimento</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {notifications.length > 0 && (
              <button
                onClick={() => onClearAllNotifications(notifications.map(n => n.id))}
                className="text-[11px] text-slate-400 hover:text-red-400 font-bold px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors flex items-center gap-1"
                title="Limpar todos os avisos"
              >
                <Trash2 size={12} /> Limpar
              </button>
            )}
            <button onClick={onClose} className="p-2 bg-slate-800 text-slate-400 hover:text-white rounded-full">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1">
          {notifications.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-sm space-y-2">
              <CheckCircle2 size={40} className="mx-auto text-emerald-500 opacity-60" />
              <p className="font-bold text-slate-300">Tudo em dia!</p>
              <p className="text-xs text-slate-500">Nenhum aviso pendente no momento.</p>
            </div>
          ) : (
            notifications.map(item => {
              const isExpired = item.type === 'EXPIRED';
              const isToday = item.type === 'TODAY';
              const isCard = item.type === 'CARD';

              return (
                <div
                  key={item.id}
                  onClick={() => handleAction(item)}
                  className={`p-3.5 rounded-2xl border cursor-pointer transition-all hover:scale-[1.01] active:scale-[0.99] flex items-start gap-3 relative group ${
                    isExpired 
                      ? 'bg-red-950/30 border-red-800/50' 
                      : isToday 
                      ? 'bg-amber-950/30 border-amber-800/50' 
                      : isCard
                      ? 'bg-purple-950/30 border-purple-800/50'
                      : 'bg-slate-800/60 border-slate-700/60'
                  }`}
                >
                  <div className={`p-2 rounded-xl shrink-0 mt-0.5 ${
                    isExpired 
                      ? 'bg-red-900/50 text-red-400' 
                      : isToday 
                      ? 'bg-amber-900/50 text-amber-400' 
                      : isCard
                      ? 'bg-purple-900/50 text-purple-400'
                      : 'bg-indigo-900/50 text-indigo-400'
                  }`}>
                    {isExpired ? <AlertTriangle size={18} /> : isToday ? <Clock size={18} /> : isCard ? <CreditCard size={18} /> : <Calendar size={18} />}
                  </div>

                  <div className="flex-1 min-w-0 pr-6">
                    <div className="flex justify-between items-baseline gap-2">
                      <h4 className={`text-xs font-bold truncate ${
                        isExpired ? 'text-red-300' : isToday ? 'text-amber-300' : 'text-slate-100'
                      }`}>
                        {item.title}
                      </h4>
                      {item.amount > 0 && (
                        <span className="text-xs font-extrabold text-slate-100 shrink-0">
                          R$ {item.amount.toFixed(2)}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                      {item.message}
                    </p>
                    <div className="mt-2.5 flex items-center gap-1.5">
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-white bg-indigo-600 hover:bg-indigo-500 px-2.5 py-1 rounded-lg shadow-sm">
                        Ver detalhes e pagar <ChevronRight size={12} />
                      </span>
                    </div>
                  </div>

                  {/* Dismiss individual notification button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDismissNotification(item.id);
                    }}
                    className="absolute top-3 right-3 p-1 rounded-lg text-slate-500 hover:text-white hover:bg-slate-700/60 transition-colors"
                    title="Dispensar aviso"
                  >
                    <X size={15} />
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex gap-2">
          <button
            onClick={() => {
              onClose();
              onNavigateToBills();
            }}
            className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold text-center"
          >
            Ir para Contas
          </button>
          <button
            onClick={() => {
              onClose();
              onNavigateToCards();
            }}
            className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold text-center"
          >
            Ir para Cartões
          </button>
        </div>
      </div>
    </div>
  );
};
