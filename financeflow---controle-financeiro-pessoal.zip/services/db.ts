import { 
  AppState, 
  Transaction, 
  MonthlyBill, 
  Investment, 
  CreditCard, 
  InvoiceHistory,
  PaidBillArchive,
  DeletedBillArchive,
  Goal,
  GoalHistoryEntry,
  AutoIncomeRule,
  RetentionSettings,
  RetentionOption,
  PaidCardInvoice
} from '../types';
import { DEFAULT_INVESTMENT_FOLDERS } from '../constants';

const STORAGE_KEY = 'finance_flow_db_v2';

const defaultRetention: RetentionSettings = {
  paidBillsRetention: 'NEVER',
  deletedBillsRetention: 'NEVER'
};

const defaultInitialState: AppState = {
  transactions: [
    {
      id: 'init_tx_1',
      type: 'INCOME',
      amount: 4500,
      category: 'Trabalho / Salário',
      date: new Date(Date.now() - 86400000 * 3).toISOString().slice(0, 16),
      description: 'Salário Mensal',
      paymentMethod: 'Dinheiro / Pix'
    },
    {
      id: 'init_tx_2',
      type: 'EXPENSE',
      amount: 180.50,
      category: 'Alimentação',
      date: new Date(Date.now() - 86400000 * 1).toISOString().slice(0, 16),
      description: 'Supermercado Mensal',
      paymentMethod: 'Cartão de Débito'
    }
  ],
  bills: [
    {
      id: 'init_bill_1',
      name: 'Internet Fibra 500MB',
      amount: 120.00,
      dueDates: [new Date().toISOString().slice(0, 8) + '15'],
      paidDueDates: [],
      isPaid: false,
      category: 'Moradia'
    },
    {
      id: 'init_bill_2',
      name: 'Condomínio',
      amount: 380.00,
      dueDates: [new Date().toISOString().slice(0, 8) + '10'],
      paidDueDates: [],
      isPaid: false,
      category: 'Moradia'
    }
  ],
  paidBillsHistory: [],
  deletedBillsHistory: [],
  goals: [
    {
      id: 'init_goal_1',
      title: 'Placa de Vídeo RTX 4070',
      targetAmount: 4200,
      currentAmount: 1650,
      category: 'Eletrônicos & PC',
      notes: 'Para upgrade no PC gamer de trabalho e lazer',
      deadline: new Date(Date.now() + 86400000 * 90).toISOString().slice(0, 10),
      createdAt: new Date().toISOString(),
      status: 'IN_PROGRESS',
      history: [
        {
          id: 'gh_1',
          date: new Date(Date.now() - 86400000 * 15).toISOString(),
          amount: 1000,
          type: 'DEPOSIT',
          note: 'Primeiro aporte com bônus'
        },
        {
          id: 'gh_2',
          date: new Date(Date.now() - 86400000 * 2).toISOString(),
          amount: 650,
          type: 'DEPOSIT',
          note: 'Economia do mês'
        }
      ]
    },
    {
      id: 'init_goal_2',
      title: 'Reserva de Emergência',
      targetAmount: 10000,
      currentAmount: 3500,
      category: 'Reserva Financeira',
      notes: '6 meses de custo fixo guardados',
      createdAt: new Date().toISOString(),
      status: 'IN_PROGRESS',
      history: [
        {
          id: 'gh_3',
          date: new Date(Date.now() - 86400000 * 30).toISOString(),
          amount: 3500,
          type: 'DEPOSIT',
          note: 'Início da reserva'
        }
      ]
    }
  ],
  autoIncomeRules: [
    {
      id: 'rule_salario_exemplo',
      name: 'Adiantamento & Salário',
      amount: 2200,
      daysOfMonth: [10, 20],
      category: 'Trabalho / Salário',
      paymentMethod: 'Dinheiro / Pix',
      active: true,
      processedDays: {}
    }
  ],
  investments: [
    {
      id: 'inv_1',
      name: 'Bitcoin (BTC)',
      amount: 3200,
      date: new Date(Date.now() - 86400000 * 20).toISOString().slice(0, 10),
      type: 'CRYPTOCURRENCY',
      folder: 'Cripto',
      notes: 'Carteira fria de longo prazo'
    },
    {
      id: 'inv_2',
      name: 'Ethereum (ETH)',
      amount: 1800,
      date: new Date(Date.now() - 86400000 * 18).toISOString().slice(0, 10),
      type: 'CRYPTOCURRENCY',
      folder: 'Cripto',
      notes: 'Staking'
    },
    {
      id: 'inv_3',
      name: 'Tesouro Selic 2029',
      amount: 5000,
      date: new Date(Date.now() - 86400000 * 45).toISOString().slice(0, 10),
      type: 'FIXED_INCOME',
      folder: 'Renda Fixa',
      notes: 'Liquidez D+1'
    }
  ],
  investmentFolders: DEFAULT_INVESTMENT_FOLDERS,
  cards: [
    {
      id: 'card_nubank',
      bankName: 'Nubank Roxinho',
      limit: 3500,
      dueDay: 15,
      color: '#820ad1'
    }
  ],
  invoiceHistory: [],
  paidCardInvoices: [],
  retentionSettings: defaultRetention,
  dismissedNotificationIds: [],
  autoBackupEnabled: true
};

function getRetentionDays(option: RetentionOption): number | null {
  switch (option) {
    case '30_DAYS': return 30;
    case '60_DAYS': return 60;
    case '90_DAYS': return 90;
    case '180_DAYS': return 180;
    case '365_DAYS': return 365;
    case 'NEVER':
    default:
      return null;
  }
}

export const db = {
  save: (state: AppState) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.error('Failed to save to localStorage', e);
    }
  },

  load: (): { state: AppState; autoIncomesAdded: { ruleName: string; amount: number; day: number }[] } => {
    let raw = localStorage.getItem(STORAGE_KEY);
    // Legacy migration check from v1
    if (!raw) {
      const legacyRaw = localStorage.getItem('finance_flow_db');
      if (legacyRaw) {
        try {
          const legacy = JSON.parse(legacyRaw);
          raw = JSON.stringify({
            ...defaultInitialState,
            transactions: legacy.transactions || [],
            bills: legacy.bills || [],
            cards: legacy.cards || [],
            investments: legacy.investments || [],
            invoiceHistory: legacy.invoiceHistory || []
          });
        } catch (e) {
          raw = null;
        }
      }
    }

    let state: AppState = raw ? JSON.parse(raw) : JSON.parse(JSON.stringify(defaultInitialState));

    // Normalize state data structure & migrations
    if (!Array.isArray(state.transactions)) state.transactions = [];
    if (!Array.isArray(state.bills)) state.bills = [];
    if (!Array.isArray(state.paidBillsHistory)) state.paidBillsHistory = [];
    if (!Array.isArray(state.deletedBillsHistory)) state.deletedBillsHistory = [];
    if (!Array.isArray(state.goals)) state.goals = [];
    if (!Array.isArray(state.autoIncomeRules)) state.autoIncomeRules = [];
    if (!Array.isArray(state.investments)) state.investments = [];
    if (!Array.isArray(state.investmentFolders) || state.investmentFolders.length === 0) {
      state.investmentFolders = DEFAULT_INVESTMENT_FOLDERS;
    }
    if (!Array.isArray(state.cards)) state.cards = [];
    if (!Array.isArray(state.invoiceHistory)) state.invoiceHistory = [];
    if (!Array.isArray(state.paidCardInvoices)) state.paidCardInvoices = [];
    if (!Array.isArray(state.dismissedNotificationIds)) state.dismissedNotificationIds = [];
    if (!state.retentionSettings) state.retentionSettings = defaultRetention;

    // Migrate bills to support multiple dueDates
    state.bills = state.bills.map(b => {
      const dueDates = Array.isArray(b.dueDates) && b.dueDates.length > 0 
        ? b.dueDates 
        : (b.dueDate ? [b.dueDate] : [new Date().toISOString().slice(0, 10)]);
      const paidDueDates = Array.isArray(b.paidDueDates) 
        ? b.paidDueDates 
        : (b.isPaid ? dueDates : []);
      return {
        ...b,
        dueDates,
        paidDueDates,
        isPaid: dueDates.length > 0 && dueDates.every(d => paidDueDates.includes(d))
      };
    });

    // Migrate investments to ensure folder exists
    state.investments = state.investments.map(i => {
      if (!i.folder) {
        if (i.type === 'CRYPTOCURRENCY') return { ...i, folder: 'Cripto' };
        if (i.type === 'STOCKS') return { ...i, folder: 'Ações' };
        if (i.type === 'FUNDS') return { ...i, folder: 'FIIs' };
        if (i.type === 'FIXED_INCOME') return { ...i, folder: 'Renda Fixa' };
        return { ...i, folder: 'Geral' };
      }
      return i;
    });

    // Apply retention cleanup (if configured, without deleting default vitalício)
    state = db.applyRetention(state);

    // Process automated salary/income addition
    const { updatedState, autoIncomesAdded } = db.processAutoIncomes(state);
    state = updatedState;

    // Save normalized state
    db.save(state);

    return { state, autoIncomesAdded };
  },

  applyRetention: (state: AppState): AppState => {
    const now = Date.now();

    // Paid bills retention
    const paidDays = getRetentionDays(state.retentionSettings.paidBillsRetention);
    if (paidDays !== null) {
      const cutoff = now - (paidDays * 86400000);
      state.paidBillsHistory = state.paidBillsHistory.filter(item => new Date(item.paidAt).getTime() >= cutoff);
    }

    // Deleted bills retention
    const deletedDays = getRetentionDays(state.retentionSettings.deletedBillsRetention);
    if (deletedDays !== null) {
      const cutoff = now - (deletedDays * 86400000);
      state.deletedBillsHistory = state.deletedBillsHistory.filter(item => new Date(item.deletedAt).getTime() >= cutoff);
    }

    return state;
  },

  processAutoIncomes: (state: AppState): { updatedState: AppState; autoIncomesAdded: { ruleName: string; amount: number; day: number }[] } => {
    const today = new Date();
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth() + 1; // 1 to 12
    const currentDay = today.getDate();
    const autoIncomesAdded: { ruleName: string; amount: number; day: number }[] = [];
    let stateChanged = false;

    state.autoIncomeRules.forEach(rule => {
      if (!rule.active) return;
      if (!rule.processedDays) rule.processedDays = {};

      rule.daysOfMonth.forEach(dayNumber => {
        // Only credit when today is EXACTLY the configured day
        if (currentDay === dayNumber) {
          const dayKey = `${currentYear}-${String(currentMonth).padStart(2, '0')}-${String(dayNumber).padStart(2, '0')}`;
          
          if (!rule.processedDays[dayKey]) {
            // Mark processed
            rule.processedDays[dayKey] = true;

            // Generate automatic income transaction
            const dateStr = `${dayKey}T08:00`;
            const newTx: Transaction = {
              id: 'auto_' + Math.random().toString(36).substr(2, 9),
              type: 'INCOME',
              amount: rule.amount,
              category: rule.category || 'Trabalho / Salário',
              date: dateStr,
              description: `[Automático] ${rule.name} (Dia ${dayNumber})`,
              paymentMethod: rule.paymentMethod || 'Dinheiro / Pix',
              isAutoIncome: true
            };

            state.transactions.unshift(newTx);
            autoIncomesAdded.push({
              ruleName: rule.name,
              amount: rule.amount,
              day: dayNumber
            });
            stateChanged = true;
          }
        }
      });
    });

    return { updatedState: state, autoIncomesAdded };
  },

  restore: (state: AppState) => {
    db.save(state);
    return state;
  },

  // Transactions
  addTransaction: (transaction: Transaction) => {
    const { state } = db.load();
    state.transactions.unshift(transaction);
    db.save(state);
    return state;
  },
  updateTransaction: (transaction: Transaction) => {
    const { state } = db.load();
    state.transactions = state.transactions.map(t => t.id === transaction.id ? transaction : t);
    db.save(state);
    return state;
  },
  deleteTransaction: (id: string) => {
    const { state } = db.load();
    state.transactions = state.transactions.filter(t => t.id !== id);
    db.save(state);
    return state;
  },

  // Bills
  addBill: (bill: MonthlyBill) => {
    const { state } = db.load();
    state.bills.push(bill);
    db.save(state);
    return state;
  },
  updateBill: (bill: MonthlyBill) => {
    const { state } = db.load();
    state.bills = state.bills.map(b => b.id === bill.id ? bill : b);
    db.save(state);
    return state;
  },
  deleteBill: (id: string) => {
    const { state } = db.load();
    const billToDelete = state.bills.find(b => b.id === id);
    if (billToDelete) {
      // Vitalício: add to deleted bills history
      state.deletedBillsHistory.unshift({
        id: 'del_' + Math.random().toString(36).substr(2, 9),
        originalId: billToDelete.id,
        name: billToDelete.name,
        amount: billToDelete.amount,
        dueDates: billToDelete.dueDates || (billToDelete.dueDate ? [billToDelete.dueDate] : []),
        deletedAt: new Date().toISOString(),
        category: billToDelete.category
      });
      state.bills = state.bills.filter(b => b.id !== id);
      db.save(state);
    }
    return state;
  },
  restoreDeletedBill: (deletedId: string) => {
    const { state } = db.load();
    const item = state.deletedBillsHistory.find(d => d.id === deletedId);
    if (item) {
      state.bills.push({
        id: item.originalId || ('bill_' + Math.random().toString(36).substr(2, 9)),
        name: item.name,
        amount: item.amount,
        dueDates: item.dueDates || [new Date().toISOString().slice(0, 10)],
        paidDueDates: [],
        isPaid: false,
        category: item.category
      });
      state.deletedBillsHistory = state.deletedBillsHistory.filter(d => d.id !== deletedId);
      db.save(state);
    }
    return state;
  },
  deletePermanentlyFromTrash: (deletedId: string) => {
    const { state } = db.load();
    state.deletedBillsHistory = state.deletedBillsHistory.filter(d => d.id !== deletedId);
    db.save(state);
    return state;
  },
  clearDeletedBillsHistory: () => {
    const { state } = db.load();
    state.deletedBillsHistory = [];
    db.save(state);
    return state;
  },

  // Paid Bills & Multi-due date management
  toggleBillDueDate: (billId: string, dueDate: string) => {
    const { state } = db.load();
    state.bills = state.bills.map(b => {
      if (b.id !== billId) return b;
      const isCurrentlyPaid = b.paidDueDates.includes(dueDate);
      const newPaidDueDates = isCurrentlyPaid 
        ? b.paidDueDates.filter(d => d !== dueDate)
        : [...b.paidDueDates, dueDate];
      
      const allPaid = b.dueDates.length > 0 && b.dueDates.every(d => newPaidDueDates.includes(d));
      return {
        ...b,
        paidDueDates: newPaidDueDates,
        isPaid: allPaid
      };
    });
    db.save(state);
    return state;
  },

  markBillAllPaid: (billId: string) => {
    const { state } = db.load();
    state.bills = state.bills.map(b => {
      if (b.id !== billId) return b;
      return {
        ...b,
        paidDueDates: [...b.dueDates],
        isPaid: true
      };
    });
    db.save(state);
    return state;
  },

  archivePaidBill: (billId: string) => {
    const { state } = db.load();
    const bill = state.bills.find(b => b.id === billId);
    if (bill) {
      state.paidBillsHistory.unshift({
        id: 'pbh_' + Math.random().toString(36).substr(2, 9),
        billId: bill.id,
        name: bill.isSubscription ? `${bill.name} (Assinatura Mensal)` : bill.name,
        amount: bill.amount,
        dueDates: [...bill.dueDates],
        paidAt: new Date().toISOString(),
        notes: bill.notes
      });

      if (bill.isSubscription) {
        // Continuous monthly subscription: advance to next month and move to end of queue
        const currentDueDateStr = bill.dueDates[0] || new Date().toISOString().slice(0, 10);
        const parts = currentDueDateStr.split('-');
        const y = parseInt(parts[0]);
        const m = parseInt(parts[1]) - 1; // 0-indexed month
        const d = bill.subscriptionDay || parseInt(parts[2]);
        const nextMonthDate = new Date(y, m + 1, d);
        const nextDateStr = `${nextMonthDate.getFullYear()}-${String(nextMonthDate.getMonth() + 1).padStart(2, '0')}-${String(nextMonthDate.getDate()).padStart(2, '0')}`;

        // Remove from current position and append to end of active bills
        state.bills = state.bills.filter(b => b.id !== billId);
        state.bills.push({
          ...bill,
          dueDates: [nextDateStr],
          paidDueDates: [],
          isPaid: false,
          pendingArchiving: false
        });
      } else {
        // Standard bill: remove from active bills
        state.bills = state.bills.filter(b => b.id !== billId);
      }
      db.save(state);
    }
    return state;
  },

  restorePaidBill: (archiveId: string) => {
    const { state } = db.load();
    const item = state.paidBillsHistory.find(h => h.id === archiveId);
    if (item) {
      state.bills.push({
        id: item.billId || ('bill_' + Math.random().toString(36).substr(2, 9)),
        name: item.name,
        amount: item.amount,
        dueDates: item.dueDates || [new Date().toISOString().slice(0, 10)],
        paidDueDates: [],
        isPaid: false,
        notes: item.notes
      });
      state.paidBillsHistory = state.paidBillsHistory.filter(h => h.id !== archiveId);
      db.save(state);
    }
    return state;
  },

  deletePaidBillFromHistory: (archiveId: string) => {
    const { state } = db.load();
    state.paidBillsHistory = state.paidBillsHistory.filter(h => h.id !== archiveId);
    db.save(state);
    return state;
  },

  clearPaidBillsHistory: () => {
    const { state } = db.load();
    state.paidBillsHistory = [];
    db.save(state);
    return state;
  },

  // Credit Cards
  addCard: (card: CreditCard) => {
    const { state } = db.load();
    state.cards.push(card);
    db.save(state);
    return state;
  },
  updateCard: (card: CreditCard) => {
    const { state } = db.load();
    state.cards = state.cards.map(c => c.id === card.id ? card : c);
    db.save(state);
    return state;
  },
  deleteCard: (id: string) => {
    const { state } = db.load();
    state.cards = state.cards.filter(c => c.id !== id);
    state.paidCardInvoices = state.paidCardInvoices.filter(p => p.cardId !== id);
    state.transactions = state.transactions.map(t => t.cardId === id ? { ...t, cardId: undefined, paymentMethod: 'Outro' } : t);
    db.save(state);
    return state;
  },

  // Paying Credit Card Invoice (Fatura Paga)
  payCardInvoice: (cardId: string, amountPaid: number, totalInvoice: number, debitFromCash: boolean) => {
    const { state } = db.load();
    const card = state.cards.find(c => c.id === cardId);
    const now = new Date();

    if (card) {
      // 1. Create PaidCardInvoice entry
      const paidRecord: PaidCardInvoice = {
        id: 'pci_' + Math.random().toString(36).substr(2, 9),
        cardId: card.id,
        cardName: card.bankName,
        amountPaid,
        totalInvoiceAmount: totalInvoice,
        paidAt: now.toISOString(),
        month: now.getMonth(),
        year: now.getFullYear()
      };
      state.paidCardInvoices.unshift(paidRecord);

      // 2. If debitFromCash is true, add an EXPENSE transaction in cash
      if (debitFromCash) {
        state.transactions.unshift({
          id: 'pay_card_' + Math.random().toString(36).substr(2, 9),
          type: 'EXPENSE',
          amount: amountPaid,
          category: 'Outros',
          date: now.toISOString().slice(0, 16),
          description: `Pagamento Fatura ${card.bankName}`,
          paymentMethod: 'Dinheiro / Pix',
          isCardInvoicePayment: true
        });
      }

      db.save(state);
    }
    return state;
  },

  updatePaidCardInvoice: (invoiceId: string, newAmount: number, newDate: string) => {
    const { state } = db.load();
    const invoice = state.paidCardInvoices.find(p => p.id === invoiceId);
    if (invoice) {
      const oldAmount = invoice.amountPaid;
      invoice.amountPaid = newAmount;
      invoice.paidAt = newDate;

      // Also adjust matching transaction
      const tx = state.transactions.find(t => 
        t.isCardInvoicePayment && 
        (t.description?.includes(invoice.cardName) || Math.abs(t.amount - oldAmount) < 0.05)
      );
      if (tx) {
        tx.amount = newAmount;
        tx.date = newDate.slice(0, 16);
      }

      db.save(state);
    }
    return state;
  },

  deletePaidCardInvoice: (invoiceId: string) => {
    const { state } = db.load();
    const invoice = state.paidCardInvoices.find(p => p.id === invoiceId);
    if (invoice) {
      state.transactions = state.transactions.filter(t => 
        !(t.isCardInvoicePayment && t.description?.includes(invoice.cardName) && Math.abs(t.amount - invoice.amountPaid) < 0.05)
      );
      state.paidCardInvoices = state.paidCardInvoices.filter(p => p.id !== invoiceId);
      db.save(state);
    }
    return state;
  },

  // Goals (Metas)
  addGoal: (goal: Goal, debitFromCash: boolean = true) => {
    const { state } = db.load();
    state.goals.unshift(goal);

    // If initial amount > 0 and debitFromCash is true, register an EXPENSE in cash
    if (debitFromCash && goal.currentAmount > 0) {
      state.transactions.unshift({
        id: 'goal_init_' + Math.random().toString(36).substr(2, 9),
        type: 'EXPENSE',
        amount: goal.currentAmount,
        category: 'Metas / Objetivos',
        date: new Date().toISOString().slice(0, 16),
        description: `Início Meta: ${goal.title}`,
        paymentMethod: 'Dinheiro / Pix'
      });
    }

    db.save(state);
    return state;
  },
  updateGoal: (goal: Goal) => {
    const { state } = db.load();
    state.goals = state.goals.map(g => g.id === goal.id ? goal : g);
    db.save(state);
    return state;
  },
  deleteGoal: (id: string) => {
    const { state } = db.load();
    state.goals = state.goals.filter(g => g.id !== id);
    db.save(state);
    return state;
  },
  contributeToGoal: (goalId: string, amount: number, type: 'DEPOSIT' | 'WITHDRAW', note: string, debitFromCash: boolean) => {
    const { state } = db.load();
    const goal = state.goals.find(g => g.id === goalId);
    if (goal) {
      const now = new Date();
      const historyEntry: GoalHistoryEntry = {
        id: 'gh_' + Math.random().toString(36).substr(2, 9),
        date: now.toISOString(),
        amount,
        type,
        note: note || (type === 'DEPOSIT' ? 'Aporte de valor' : 'Resgate de valor')
      };
      
      goal.history.unshift(historyEntry);
      if (type === 'DEPOSIT') {
        goal.currentAmount += amount;
      } else {
        goal.currentAmount = Math.max(0, goal.currentAmount - amount);
      }

      if (goal.currentAmount >= goal.targetAmount) {
        goal.status = 'COMPLETED';
      } else {
        goal.status = 'IN_PROGRESS';
      }

      // If user chose to sync with cash balance:
      if (debitFromCash) {
        if (type === 'DEPOSIT') {
          state.transactions.unshift({
            id: 'goal_tx_' + Math.random().toString(36).substr(2, 9),
            type: 'EXPENSE',
            amount,
            category: 'Metas / Objetivos',
            date: now.toISOString().slice(0, 16),
            description: `Aporte Meta: ${goal.title}`,
            paymentMethod: 'Dinheiro / Pix'
          });
        } else {
          state.transactions.unshift({
            id: 'goal_tx_' + Math.random().toString(36).substr(2, 9),
            type: 'INCOME',
            amount,
            category: 'Metas / Objetivos',
            date: now.toISOString().slice(0, 16),
            description: `Resgate Meta: ${goal.title}`,
            paymentMethod: 'Dinheiro / Pix'
          });
        }
      }

      db.save(state);
    }
    return state;
  },

  toggleGoalFocus: (goalId: string) => {
    const { state } = db.load();
    state.goals = state.goals.map(g => g.id === goalId ? { ...g, isFocus: !g.isFocus } : g);
    db.save(state);
    return state;
  },

  // Auto Income Rules
  addAutoIncomeRule: (rule: AutoIncomeRule) => {
    const { state } = db.load();
    const today = new Date();
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth() + 1;
    const currentDay = today.getDate();

    if (!rule.processedDays) rule.processedDays = {};
    // Mark past days or today as processed so it won't drop cash retroactively on creation!
    rule.daysOfMonth.forEach(d => {
      if (d <= currentDay) {
        const dayKey = `${currentYear}-${String(currentMonth).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
        rule.processedDays[dayKey] = true;
      }
    });

    state.autoIncomeRules.push(rule);
    db.save(state);
    return state;
  },
  updateAutoIncomeRule: (rule: AutoIncomeRule) => {
    const { state } = db.load();
    state.autoIncomeRules = state.autoIncomeRules.map(r => r.id === rule.id ? rule : r);
    db.save(state);
    return state;
  },
  deleteAutoIncomeRule: (id: string) => {
    const { state } = db.load();
    state.autoIncomeRules = state.autoIncomeRules.filter(r => r.id !== id);
    db.save(state);
    return state;
  },
  toggleAutoIncomeRule: (id: string) => {
    const { state } = db.load();
    state.autoIncomeRules = state.autoIncomeRules.map(r => r.id === id ? { ...r, active: !r.active } : r);
    db.save(state);
    return state;
  },

  // Investments
  addInvestment: (investment: Investment, debitFromCash: boolean = true) => {
    const { state } = db.load();
    state.investments.push(investment);
    if (investment.folder && !state.investmentFolders.includes(investment.folder)) {
      state.investmentFolders.push(investment.folder);
    }

    if (debitFromCash && investment.amount > 0) {
      state.transactions.unshift({
        id: 'inv_exp_' + Math.random().toString(36).substr(2, 9),
        type: 'EXPENSE',
        amount: investment.amount,
        category: 'Investimentos',
        date: investment.date ? `${investment.date}T12:00` : new Date().toISOString().slice(0, 16),
        description: `Aporte Investimento: ${investment.name}`,
        paymentMethod: 'Dinheiro / Pix'
      });
    }

    db.save(state);
    return state;
  },
  aporteToExistingInvestment: (investmentId: string, additionalAmount: number, date: string, note?: string, debitFromCash: boolean = true) => {
    const { state } = db.load();
    const inv = state.investments.find(i => i.id === investmentId);
    if (inv) {
      inv.amount += additionalAmount;
      inv.date = date;
      const aporteNote = `Aporte: +R$ ${additionalAmount.toFixed(2)}${note ? ` (${note})` : ''}`;
      inv.notes = inv.notes ? `${inv.notes} • ${aporteNote}` : aporteNote;

      if (debitFromCash && additionalAmount > 0) {
        state.transactions.unshift({
          id: 'inv_exp_' + Math.random().toString(36).substr(2, 9),
          type: 'EXPENSE',
          amount: additionalAmount,
          category: 'Investimentos',
          date: date ? `${date}T12:00` : new Date().toISOString().slice(0, 16),
          description: `Aporte Investimento: ${inv.name}`,
          paymentMethod: 'Dinheiro / Pix'
        });
      }

      db.save(state);
    }
    return state;
  },
  updateInvestment: (investment: Investment) => {
    const { state } = db.load();
    state.investments = state.investments.map(i => i.id === investment.id ? investment : i);
    if (investment.folder && !state.investmentFolders.includes(investment.folder)) {
      state.investmentFolders.push(investment.folder);
    }
    db.save(state);
    return state;
  },
  deleteInvestment: (id: string) => {
    const { state } = db.load();
    state.investments = state.investments.filter(i => i.id !== id);
    db.save(state);
    return state;
  },
  addInvestmentFolder: (folderName: string) => {
    const { state } = db.load();
    if (!state.investmentFolders.includes(folderName)) {
      state.investmentFolders.push(folderName);
      db.save(state);
    }
    return state;
  },
  deleteInvestmentFolder: (folderName: string) => {
    const { state } = db.load();
    state.investmentFolders = state.investmentFolders.filter(f => f !== folderName);
    // move investments in that folder to 'Geral'
    state.investments = state.investments.map(i => i.folder === folderName ? { ...i, folder: 'Geral' } : i);
    db.save(state);
    return state;
  },

  // Retention Settings
  updateRetentionSettings: (settings: RetentionSettings) => {
    const { state } = db.load();
    state.retentionSettings = settings;
    const cleanState = db.applyRetention(state);
    db.save(cleanState);
    return cleanState;
  },

  // Dismissed Notifications
  dismissNotification: (id: string) => {
    const { state } = db.load();
    if (!Array.isArray(state.dismissedNotificationIds)) state.dismissedNotificationIds = [];
    if (!state.dismissedNotificationIds.includes(id)) {
      state.dismissedNotificationIds.push(id);
      db.save(state);
    }
    return state;
  },

  clearAllNotifications: (ids: string[]) => {
    const { state } = db.load();
    if (!Array.isArray(state.dismissedNotificationIds)) state.dismissedNotificationIds = [];
    ids.forEach(id => {
      if (!state.dismissedNotificationIds!.includes(id)) {
        state.dismissedNotificationIds!.push(id);
      }
    });
    db.save(state);
    return state;
  },

  // Backup Meta
  updateBackupMeta: (date: string) => {
    const { state } = db.load();
    state.lastBackupDate = date;
    db.save(state);
    return state;
  }
};
